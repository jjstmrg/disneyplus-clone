---
name: xss-deserializer-strips-html
description: Global Jackson Xss deserializer in common-core strips ALL HTML tags from every String field; endpoints carrying HTML must opt out
metadata: 
  node_type: memory
  type: project
  originSessionId: 92756582-1a28-4a1f-a842-641504a7edc6
---

`ulos-common-core` ships `XssAutoConfiguration` which registers `XssStringDeserializer` via `builder.deserializerByType(String.class, ...)`. It runs `Jsoup.clean(value, Safelist.none())` on EVERY incoming JSON String field in EVERY service that depends on common-core (auto-config, no opt-in). Result: any field meant to carry HTML markup arrives tag-stripped (text only) — the controller/service never sees the tags.

**Why:** Symptom is silent and misleading — frontend logs/sends correct HTML, backend "receives" plain text; looks like a frontend/browser/cache bug. Cost a long debugging session on the document-service edit-before-PDF flow (`POST /api/loans/v1/documents/generate-from-html`): the user-edited document HTML was stripped to text, producing plain (unstyled) PDFs.

**How to apply:** For request fields that legitimately carry HTML, opt the single field out with a property-level passthrough deserializer — it overrides the type-level one:
`@com.fasterxml.jackson.databind.annotation.JsonDeserialize(using = RawStringDeserializer.class) String html`
(`RawStringDeserializer` returns `parser.getValueAsString()` verbatim — see `ulos-document-service/.../adapter/inbound/RawStringDeserializer.java`). Global XSS protection on other fields stays intact. Only do this for values rendered server-side (e.g. PDF), never for values reflected back into a browser. Related: [[edit-before-pdf-flow]].
