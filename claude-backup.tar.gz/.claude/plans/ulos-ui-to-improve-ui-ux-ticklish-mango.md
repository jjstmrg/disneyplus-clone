# ULOS UI — i18n Cleanup (lanjutan Fase 1)

## Konteks

Fase 1 sudah selesai (primitif, toast global, code-splitting, dll). Saat membangun
sistem toast & primitif, beberapa string user-facing ditulis hardcoded — terutama
literal Bahasa Indonesia di store/komponen yang berjalan di luar React (tidak punya
akses `t()`). Ini melanggar standar i18n.

Tujuan: nol string user-facing hardcoded. Semua teks lewat `translations.ts`.
Primitif menerima teks via prop. Kode non-React memakai helper `translate()` standalone.

**Keputusan dari user:**
- Prop teks di primitif **wajib**, tanpa default tertanam.
- errorCode: **frontend dulu, backend ditunda**. Backend `ApiErrorResponse`
  (`ulos-common-core`, shared) belum punya field `errorCode` — hanya `message`
  English hardcoded di `GlobalExceptionHandler.java`. FE bangun mekanisme pemetaan
  `errorCode → key i18n` + helper `resolveApiError` sekarang (siap pakai begitu
  backend kirim code). Perubahan backend (tambah `errorCode`, externalisasi pesan ke
  file terpisah) = task terpisah Squad Backend/Common-Lib — **di luar scope ini**.

## Pendekatan

### 1. `src/locales/translations.ts` — helper + key baru

Tambah di akhir file (setelah `translations` & `TranslationKey`):
- `type Language = 'ID' | 'EN'`, `type TranslationParams = Record<string, string | number>`.
- `interpolate(text, params?)` — ganti placeholder `{nama}` dengan nilai param.
- `getCurrentLanguage()` — baca `localStorage['ulos-lang']`, default `'EN'` (samakan dengan `LanguageContext`).
- `translate(key, params?, lang?)` — lookup + interpolate, untuk kode non-React.

Tambah key baru (ID + EN, set key identik):
| Key | ID |
|-----|-----|
| `bpmn_xml_invalid` | XML tidak valid |
| `bpmn_deploy_success` | BPMN versi {version} berhasil di-deploy dan diaktifkan |
| `bpmn_activate_success` | Versi berhasil diaktifkan |
| `bpmn_deactivate_success` | Versi berhasil dinonaktifkan |
| `bpmn_load_active_failed` | Gagal memuat versi aktif |
| `bpmn_load_history_failed` | Gagal memuat riwayat |
| `bpmn_deploy_failed` | Deploy gagal |
| `bpmn_activate_failed` | Gagal mengaktifkan versi |
| `bpmn_deactivate_failed` | Gagal menonaktifkan versi |
| `bpmn_file_invalid` | Format file tidak valid |
| `bpmn_xml_required` | BPMN XML belum diupload |
| `bpmn_file_format_error` | File harus berformat .bpmn atau .xml |
| `bpmn_xml_required_error` | BPMN XML wajib diupload |
| `bpmn_version_required` | Version wajib diisi |
| `bpmn_version_invalid` | Format version harus semantic versioning (contoh: 1.0.0) |
| `facility_delete_failed` | Gagal menghapus fasilitas |
| `cancel` | Batal |
| `pagination_summary` | Menampilkan {from}–{to} dari {total} |
| `pagination_prev` | Halaman sebelumnya |
| `pagination_next` | Halaman berikutnya |

Reuse key yang sudah ada: `close` (Tutup), `no_data`, `error`.

### 2. `src/contexts/LanguageContext.tsx`

`t` diperluas: `(key: TranslationKey, params?: TranslationParams) => string`, pakai
`interpolate`. Backward-compatible — semua `t('x')` lama tetap valid.

### 3. Helper resolusi error API — `src/lib/errorMessages.ts` (baru)

`resolveApiError(err, fallbackKey?)`:
- Prioritas: `errorCode` backend yang terpetakan → `translate(key)`; else `message`
  backend apa adanya; else `translate(fallbackKey)`.
- `ERROR_CODE_KEYS: Record<string, TranslationKey>` — **kosong dulu** (backend belum
  kirim `errorCode`); mekanisme siap, key ditambah saat backend menyusul.

### 4. Ganti string hardcoded

- **`src/store/useBpmnStore.ts`** (non-React) — `toast.*` literal → `translate('key', params)`.
  Catch block: `toast.error(resolveApiError(err, 'bpmn_..._failed'))` — tidak ada lagi
  literal `|| 'Gagal ...'`.
- **`src/components/bpmn/DeployForm.tsx`** — `toast.error(...)` & `setState({ error })`
  literal → `translate('key')`. Termasuk error `validateVersion`.
- **`src/components/wizard/MultiFacilityStep.tsx`** — `toast.error(...)` → `t('facility_delete_failed')`
  (komponen ini sudah punya `t`).
- **`src/pages/ApprovalQueuePage.tsx`** — ternary `lang === 'ID' ? 'Batal' : 'Cancel'`
  → `t('cancel')`.

### 5. Primitif terima teks via prop (wajib, tanpa default)

- **`src/components/ui/Table.tsx`**
  - `Table`: `emptyTitle` jadi prop **wajib** (hapus default `'Tidak ada data'`).
  - `TablePagination`: hapus literal "Menampilkan…" + aria-label hardcoded. Tambah prop
    wajib `summary: (from: number, to: number, total: number) => string`,
    `previousLabel: string`, `nextLabel: string`.
- **`src/components/ui/Modal.tsx`** — `aria-label="Tutup"` → prop wajib `closeLabel: string`.
- **`src/components/ui/index.ts`** — tak ada export baru; tipe prop sudah ikut ter-reexport.

### 6. Update caller primitif

- **`src/pages/TemplatePage.tsx`** — pakai `useLanguage()`, kirim prop wajib:
  `emptyTitle={t('no_data')}`, `closeLabel={t('close')}`, dan label `TablePagination`
  (`summary` pakai `t('pagination_summary', {from,to,total})`, `previousLabel`/`nextLabel`).
- **`src/pages/ApprovalQueuePage.tsx`** — `Modal` tambah `closeLabel={t('close')}`.

### 7. `docs/FRONTEND_STANDARDS.md` — bagian i18n

Tambah aturan eksplisit:
- Tidak ada string user-facing hardcoded — semua di `translations.ts`.
- Primitif tidak tahu i18n; terima teks via prop dari caller.
- Komponen React pakai `t()`; kode non-React (store) pakai `translate()` (key, bukan literal).
- Error API lewat `resolveApiError()`. Pemetaan `errorCode → key` siap di FE; backend
  belum kirim `errorCode` → ditunda (task Squad Backend/Common-Lib): tambah field
  `errorCode` ke `ApiErrorResponse` + externalisasi pesan English ke file terpisah.

### 8. `src/locales/translations.test.ts` — perluas

Test parity ID/EN sudah ada (gagal jika key hanya di satu bahasa) — dipertahankan.
Tambah: test `translate()` + `interpolate()` (placeholder `{x}` terganti, key tak
dikenal fallback ke key string), dan assert tak ada value berisi hanya whitespace.

## File yang disentuh

- `src/locales/translations.ts` — key baru + `interpolate`/`getCurrentLanguage`/`translate`
- `src/contexts/LanguageContext.tsx` — `t` dukung params
- `src/lib/errorMessages.ts` (baru) — helper `resolveApiError`
- `src/store/useBpmnStore.ts`, `src/components/bpmn/DeployForm.tsx`,
  `src/components/wizard/MultiFacilityStep.tsx`, `src/pages/ApprovalQueuePage.tsx` — ganti literal
- `src/components/ui/Table.tsx`, `src/components/ui/Modal.tsx` — prop teks wajib
- `src/pages/TemplatePage.tsx` — kirim prop wajib
- `docs/FRONTEND_STANDARDS.md` — aturan i18n
- `src/locales/translations.test.ts` — perluas test

## Verifikasi

- `npm run test` — parity ID/EN lulus, test `translate`/`interpolate` baru lulus, 6 test primitif tetap lulus.
- `npm run build` + `npm run lint` — bersih (TypeScript akan menandai caller primitif yang belum kirim prop wajib — itu jaring pengaman).
- `npm run dev`: `/admin/bpmn-deploy` deploy/validate → toast tampil teks benar; ganti
  bahasa ID/EN lalu picu toast lagi → bahasa ikut. `/template` → Modal, empty-state
  Table, dan label pagination tampil dari `t()`.
