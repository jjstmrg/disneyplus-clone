# Refactor: Split Flowable Engine → `ulos-bpm-service`

## Context

`ulos-orchestration-service` saat ini embed Flowable 7.2 engine bersama domain loan application (18 JavaDelegates, BPMN deployment, dashboard listener, BpmnDeploymentController). Beban tunggal service ini berat: domain logic + workflow engine + 2 datasource (`orchestration` + `flowable` schemas) berdesakan di 1 JVM.

**Tujuan:** Pisahkan Flowable engine ke service baru `ulos-bpm-service` agar:
- Squad BPMN Designer punya boundary kode jelas (CLAUDE.md line 168-172)
- Engine bisa scale terpisah (HPA on Kafka lag) tanpa rebuild domain service
- Failure isolation — engine restart tidak bunuh API loan submission
- Schema ownership tegas: `orchestration` schema dimiliki orchestration-service, `flowable` schema dimiliki bpm-service

**Constraint user:**
- DB tetap shared (`ulos_orchestration` Postgres instance) — schema `flowable` yang sudah ada dipakai bpm-service
- Tetap perhatikan performance, security, scalability, resilience
- Tidak boleh langgar `ArchitectureComplianceTest` di common-lib

**Keputusan user (sudah dikonfirmasi):**
1. Nama: `ulos-bpm-service`
2. Start process: Kafka event via outbox (orchestration → bpm-service)
3. Callback domain update: Kafka event via outbox (bpm-service → orchestration)
4. `tb_bpmn_deployment` pindah ke schema `flowable`

---

## Arsitektur Target

```
[ulos-ui] → [api-gateway] → [orchestration-service]      [bpm-service]
                                  │  (domain only)            │  (Flowable engine)
                                  │                           │
                                  └──── outbox ───Kafka───→ consumer
                                       (start req)              │
                                                                ├─ runtimeService.startProcessInstanceByKey()
                                                                ├─ delegate execution (Feign → rule, integration)
                                                                ▼
                                  ┌──── consumer ←─Kafka── outbox
                                  │   (state changed)         (process state events)
                                  ▼
                            update LoanApplicationEntity

Database: ulos_orchestration (Postgres, shared)
  ├── schema `orchestration`   → owned by orchestration-service
  ├── schema `flowable`        → owned by bpm-service (ACT_* + tb_bpmn_deployment + outbox + dedupe)
  └── schema `audit`           → shared (common-jpa-audit)
```

**Cross-schema rule:** Tidak ada FK / JOIN antar schema. Komunikasi 100% via Kafka outbox.

---

## Kafka Contract

Tambah di `ulos-common-lib/src/main/java/com/ulos/common/kafka/KafkaTopics.java`:

```java
public static final String BPM_PROCESS_START_REQUESTED = "ulos.bpm.process-start-requested";
public static final String BPM_PROCESS_STATE_CHANGED   = "ulos.bpm.process-state-changed";
public static final String BPM_TASK_COMPLETED          = "ulos.bpm.task-completed";
```

DTO records baru di `ulos-common-lib/src/main/java/com/ulos/common/dto/bpm/`:
- `ProcessStartRequestedEvent(UUID eventId, String applicationId, String productType, String processKey, ProcessVariableDto variables, Instant occurredAt)`
- `ProcessStateChangedEvent(UUID eventId, String applicationId, String processInstanceId, String status, String taskId, String taskName, Instant occurredAt)`
- `TaskCompletedEvent(UUID eventId, String applicationId, String taskId, String outcome, Instant occurredAt)`

Partition key: `applicationId` (ordering per app). 3 partition dev / 12 prod.

Consumer groups:
- `ulos-bpm-service.process-start`
- `ulos-orchestration-service.bpm-state`
- `ulos-orchestration-service.bpm-task`

Error handling: `ErrorHandlingDeserializer` + `DefaultErrorHandler` (3x exp backoff 2/4/8s) → DLQ ke `KafkaTopics.DEAD_LETTER` (sudah ada). Manual ack mode.

Idempotency: setiap event punya `eventId` UUID; consumer insert ke `flowable.tb_consumed_event` (PK = eventId) dalam satu Tx dengan side effect. Conflict on PK → skip.

---

## Module Baru: `ulos-bpm-service`

Tambah ke root `pom.xml`: `<module>ulos-bpm-service</module>`.

Package root: `com.ulos.bpm`. Struktur hexagonal sama dengan orchestration:

```
ulos-bpm-service/
├── pom.xml
└── src/main/
    ├── java/com/ulos/bpm/
    │   ├── BpmServiceApplication.java
    │   ├── adapter/
    │   │   ├── inbound/
    │   │   │   ├── BpmnDeploymentController.java       (moved)
    │   │   │   └── kafka/ProcessStartRequestedConsumer.java
    │   │   └── outbound/
    │   │       ├── RuleServiceClient.java              (moved Feign)
    │   │       ├── IntegrationServiceClient.java       (moved Feign)
    │   │       └── kafka/BpmEventPublisher.java        (outbox publisher)
    │   ├── bpm/
    │   │   ├── delegate/                                (17 JavaDelegates, bean names UNCHANGED)
    │   │   └── listener/
    │   │       ├── FlowableProcessEventListener.java
    │   │       ├── ApplicationWorkflowListener.java
    │   │       └── DashboardMetricListener.java         (ExecutionListener)
    │   ├── config/
    │   │   ├── FlowableAsyncConfig.java
    │   │   ├── FlowableProperties.java
    │   │   ├── KafkaConsumerConfig.java
    │   │   ├── OutboxConfig.java
    │   │   ├── SecurityConfig.java                      (OAuth2 RS, Spring Security 6)
    │   │   └── Resilience4jConfig.java
    │   ├── domain/
    │   │   ├── bpmn/{BpmnDeploymentEntity,Repository}.java
    │   │   ├── outbox/{OutboxEventEntity,Repository}.java
    │   │   └── idempotency/{ConsumedEventEntity,Repository}.java
    │   └── service/
    │       ├── bpmn/BpmnDeploymentService.java
    │       ├── ProcessStartService.java
    │       └── ProcessStateService.java
    └── resources/
        ├── application.yml, application-docker.yml
        ├── bpmn/diagram_1-v3 1.bpmn                     (moved)
        └── db/migration/V1..V3.sql
```

`pom.xml` dependencies (clone dari orchestration `pom.xml` line 43-51):
- `flowable-spring-boot-starter` + `flowable-spring-boot-starter-rest` (7.2.0)
- `spring-boot-starter-data-jpa`, `web`, `validation`, `actuator`, `oauth2-resource-server`
- `spring-kafka`, `spring-cloud-starter-openfeign`, `spring-cloud-starter-circuitbreaker-resilience4j`
- `postgresql`, `flyway-core`, `micrometer-registry-prometheus`
- `shedlock-spring`, `shedlock-provider-jdbc-template`
- Internal: `ulos-common-lib`, `ulos-common-core`, `ulos-common-security`, `ulos-common-jpa-audit`, `ulos-common-web-servlet`

---

## Database Migration

### bpm-service migrations (`ulos-bpm-service/src/main/resources/db/migration/`)

- **V1__init_flowable_schema.sql** — `CREATE SCHEMA IF NOT EXISTS flowable;`
- **V2__create_tb_bpmn_deployment.sql** — copy DDL dari `ulos-orchestration-service/src/main/resources/db/migration/V2__add_bpmn_deployment_table.sql` tapi pakai schema `flowable.tb_bpmn_deployment`.
- **V3__create_outbox_and_dedupe.sql** — outbox + `tb_consumed_event` di schema `flowable`.

### Konfigurasi engine

`flowable.database-schema: flowable` + `flowable.database-schema-update: true` → Flowable auto-create `ACT_*` di schema `flowable`. Setelah rollout pertama stabil, set `database-schema-update: false` di prod (manual schema migration via `DbSchemaCreate` utility) untuk safety.

### Cleanup di orchestration-service

- Setelah bpm-service produksi stabil, tambah migration baru di orchestration:
  - `V4__drop_orchestration_bpmn_deployment.sql` → `DROP TABLE IF EXISTS orchestration.tb_bpmn_deployment;`
- **Kalau ada data prod di `orchestration.tb_bpmn_deployment`**: tambah `V4__migrate_bpmn_deployment_data.sql` di bpm-service SEBELUM drop, isi `INSERT INTO flowable.tb_bpmn_deployment SELECT * FROM orchestration.tb_bpmn_deployment ON CONFLICT DO NOTHING;`

### Flyway versi konflik (PRE-EXISTING BUG)

Ada DUA file V2 di orchestration migrations:
- `V2__add_bpmn_deployment_table.sql`
- `V2__create_rbac_tables.sql`

Flyway akan gagal di environment baru. **HARUS DIBERESKAN dulu** sebelum refactor lanjut — rename salah satu jadi `V2.1__...` atau pisah jadi V2/V3 dan re-sequence. Cek dulu state DB existing (apakah salah satu sudah pernah eksekusi, mungkin checksum di `flyway_schema_history`).

---

## DataSource Config

**bpm-service** — single HikariCP:

```yaml
spring:
  datasource:
    url: jdbc:postgresql://${DB_HOST:localhost}:5432/ulos_orchestration?currentSchema=flowable
    username: ${DB_USER:ulos_app}
    password: ${DB_PASS}
    hikari:
      maximum-pool-size: 30
      minimum-idle: 5
      pool-name: BpmServiceHikariCP
  jpa:
    properties:
      hibernate.default_schema: flowable
    hibernate.ddl-auto: validate
  flyway:
    schemas: flowable
    default-schema: flowable
  threads.virtual.enabled: true
flowable:
  database-schema: flowable
  database-schema-update: true
  history-level: full
  async-executor-activate: true
  async-executor:
    core-pool-size: 8
    max-pool-size: 32
server:
  port: 8085
```

**orchestration-service** — edit `ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/DataSourceConfig.java`:
- HAPUS bean `flowableDataSource`, `flowableDataSourceProperties`, `flowableProcessEngineDataSourceConfigurer` (lines 39-58)
- Sisakan single primary domain datasource
- Edit `ulos-orchestration-service/src/main/resources/application.yml` line 88-105 — HAPUS seluruh blok `flowable:` + hapus `datasource.flowable` properties

---

## Process Start Flow (zero dual-write)

```
LoanOrchestrationService.submitApplication() [@Transactional]
  ├── save(LoanApplicationEntity, status=SUBMITTED)
  └── outboxRepo.save(ProcessStartRequestedEvent {applicationId, productType, processKey, vars})
        ▼
OutboxPoller @Scheduled (ShedLock) → publish KafkaTopics.BPM_PROCESS_START_REQUESTED
        ▼
[bpm-service] ProcessStartRequestedConsumer @KafkaListener [@Transactional]
  ├── ConsumedEventRepo.insert(eventId)             ← idempotent guard
  ├── ProcessStartService.start()
  │     └── runtimeService.startProcessInstanceByKey(processKey, vars)   ← NO JPA save in same tx (CLAUDE.md line 222)
  └── outboxRepo.save(ProcessStateChangedEvent {processInstanceId, status=STARTED})
        ▼
[bpm-service] OutboxPoller → publish KafkaTopics.BPM_PROCESS_STATE_CHANGED
        ▼
[orchestration-service] BpmStateChangedConsumer @KafkaListener
  └── update LoanApplicationEntity.processInstanceId + status
```

**Anti-pattern guard (CLAUDE.md line 222):** Pemisahan service otomatis enforce — `runtimeService.startProcessInstanceByKey()` di bpm-service, JPA save LoanApplicationEntity di orchestration-service. Tidak mungkin satu Tx.

**Penting:** `LoanOrchestrationService` (`ulos-orchestration-service/src/main/java/com/ulos/orchestration/service/LoanOrchestrationService.java`) — keempat `@Transactional` method-nya harus dicek: kalau ada call `runtimeService.*` langsung, ganti dengan `outboxRepo.save(ProcessStartRequestedEvent)`.

---

## Delegate Refactor

17 JavaDelegates pindah ke `com.ulos.bpm.bpm.delegate.*`. **Bean name harus tetap sama** (mis. `applicationReviewDelegate`) supaya BPMN XML existing `flowable:delegateExpression="${...}"` tidak perlu diubah.

Pattern wajib pasca-split:

```java
@Component("applicationReviewDelegate")
class ApplicationReviewDelegate implements JavaDelegate {
  private final RuleServiceClient ruleClient;     // Feign + Resilience4j
  private final BpmEventPublisher publisher;       // → tb_outbox_event in flowable schema

  public void execute(DelegateExecution ex) {
    var outcome = ruleClient.evaluate(...);
    ex.setVariable("reviewOutcome", outcome);
    publisher.publishState(applicationId, ex.getProcessInstanceId(), "REVIEWED", null, null);
  }
}
```

Feign clients pindah:
- `ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/outbound/RuleServiceClient.java` → bpm-service
- `ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/outbound/IntegrationServiceClient.java` → bpm-service
- Wrap dengan `@CircuitBreaker(name="ruleService", fallbackMethod="ruleFallback")` + `@Retry(name="ruleService")`. Config Resilience4j di `application.yml`.

Delegate TIDAK boleh tulis langsung ke `orchestration` schema — hanya via Kafka event.

---

## BpmnDeploymentController + Gateway Route

Pindah:
- `ulos-orchestration-service/.../adapter/inbound/bpmn/BpmnDeploymentController.java`
- `ulos-orchestration-service/.../service/bpmn/BpmnDeploymentService.java`
- `ulos-orchestration-service/.../domain/bpmn/{BpmnDeploymentEntity,Repository}.java`

Re-package `com.ulos.bpm.*`, update `@Table(schema="flowable", name="tb_bpmn_deployment")`.

**Gateway route update** di `ulos-api-gateway/src/main/resources/application.yml`:

```yaml
- id: bpm-service
  uri: http://ulos-bpm-service:8085
  predicates:
    - Path=/api/v1/bpmn/**
  filters:
    - TokenRelay=
```

Hapus rule `/api/v1/bpmn/**` yang sebelumnya route ke orchestration:8082.

**SecurityConfig di bpm-service:** copy bentuk dari `ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/SecurityConfig.java`. Pakai `BaseSecurityConfig` dari `ulos-common-security` + JWT converter common-lib (BUKAN `org.keycloak.adapters.*` — anti-pattern CLAUDE.md line 213). Role `ROLE_BPMN_DESIGNER` untuk write op `/api/v1/bpmn/**`.

---

## Dashboard Metrics

Pindah `ulos-orchestration-service/.../listener/DashboardMetricListener.java` → `ulos-bpm-service/.../bpm/listener/DashboardMetricListener.java`. Tetap implement Flowable `ExecutionListener`, tetap publish ke `KafkaTopics.DASHBOARD_METRICS` (sudah ada di common-lib). Consumer di notification-service tidak berubah.

`DashboardMetricService` / `DashboardQueryService` (kalau ada) tetap di orchestration — aggregat dari domain DB + SSE.

---

## Common-Lib Changes

`ulos-common-lib/`:

**Tambah:**
- `kafka/KafkaTopics.java` — tambah 3 konstanta BPM
- `dto/bpm/ProcessStartRequestedEvent.java` (record, extends `UlosEvent`)
- `dto/bpm/ProcessStateChangedEvent.java` (record)
- `dto/bpm/TaskCompletedEvent.java` (record)
- `dto/bpm/ProcessVariableDto.java` — **belum ada** di repo (sudah cek). Buat baru di sini supaya kontrak shared (CLAUDE.md line 206 sudah menyebutkan tapi belum diimplement)

**Update `ArchitectureComplianceTest`** (`ulos-common-lib/src/test/java/com/ulos/common/architecture/ArchitectureComplianceTest.java`):
- Rule: `com.ulos.orchestration..` MUST NOT depend on `org.flowable..`
- Rule: `com.ulos.bpm..` MUST NOT depend on `com.ulos.orchestration..`
- Rule: delegates di `com.ulos.bpm.bpm.delegate..` HARUS implement `org.flowable.engine.delegate.JavaDelegate`
- Rule: tidak boleh ada `@Table(schema="orchestration")` di module `ulos-bpm-service`, dan sebaliknya

---

## Files to Delete (Orchestration, Post-Verify)

Setelah parity test hijau (rollout step e):

```
ulos-orchestration-service/src/main/java/com/ulos/orchestration/bpm/                     (entire dir + listener/)
ulos-orchestration-service/src/main/java/com/ulos/orchestration/delegate/                (entire dir, CreditCheckDelegate + RuleEvaluationDelegate)
ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/FlowableAsyncConfig.java
ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/FlowableProperties.java
ulos-orchestration-service/src/main/java/com/ulos/orchestration/service/bpmn/            (entire dir)
ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/inbound/bpmn/    (entire dir)
ulos-orchestration-service/src/main/java/com/ulos/orchestration/domain/bpmn/             (entire dir)
ulos-orchestration-service/src/main/java/com/ulos/orchestration/listener/DashboardMetricListener.java
ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/outbound/RuleServiceClient.java
ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/outbound/IntegrationServiceClient.java
ulos-orchestration-service/src/main/resources/bpmn/                                      (entire dir)
ulos-orchestration-service/src/main/resources/bpmn____/                                  (entire dir, unused)
```

Edit (jangan delete):
- `ulos-orchestration-service/pom.xml` lines 43-51 — hapus dependency `flowable-spring-boot-starter` & `-rest`
- `ulos-orchestration-service/src/main/resources/application.yml` lines 88-105 — hapus blok `flowable:` + `spring.datasource.flowable`
- `ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/DataSourceConfig.java` — hapus flowable datasource bean (line 39-58); jadikan single primary

---

## Docker Compose + Observability

Tambah di `docker-compose.yml`:

```yaml
ulos-bpm-service:
  build: ./ulos-bpm-service
  container_name: ulos-bpm-service
  ports: ["8085:8085"]
  environment:
    SPRING_PROFILES_ACTIVE: docker
    DB_HOST: postgres-orchestration
    DB_USER: ulos_app
    DB_PASS: ${DB_PASS}
    KAFKA_BOOTSTRAP: kafka:9092
    OAUTH2_ISSUER_URI: http://keycloak:8080/realms/ulos
  depends_on:
    postgres-orchestration: {condition: service_healthy}
    kafka: {condition: service_started}
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:8085/actuator/health/liveness"]
    interval: 15s
  networks: [ulos-net]
```

**K8s manifests** di `infra/k8s/` — clone Deployment/Service/HPA/PodMonitor dari orchestration; replicas: 2 (Flowable handle distributed locking via `ACT_RU_JOB`); HPA on CPU 70% + Kafka consumer lag custom metric.

**Prometheus scrape** — tambah bpm-service ke `infra/prometheus/scrape-configs.yml` di endpoint `/actuator/prometheus`.

**Tracing** — Micrometer + Brave + Zipkin sudah ada di common — inherit otomatis.

---

## CLAUDE.md Updates

Edit `/Users/johanesjsitumorang/development/ulosv0/CLAUDE.md`:

- **Line 22** tree: tambah `├── ulos-bpm-service          ← Squad: BPMN Designer (Flowable engine + 17 delegates)`
- **Line 24** ubah `(Flowable engine + process)` → `(domain loan + outbox → bpm-service)`
- **Line 75-88** ganti directory map orchestration: hapus `bpm/` row. Tambah seksi baru `### ulos-bpm-service ⭐` dengan tree-nya
- **Line 168-172** Squad BPMN Designer ownership: `Owns: ulos-bpm-service/ (entire service) + *.bpmn files`
- **Line 212+** anti-pattern: tambah
  ```
  ❌ cross-service DB write (orchestration→flowable schema atau sebaliknya)
  ❌ non-idempotent Kafka consumer (wajib cek eventId di tb_consumed_event)
  ❌ delegate menulis langsung ke orchestration schema → publish event saja
  ❌ direct REST call orchestration ↔ bpm-service → wajib via Kafka outbox
  ```

---

## Testing Strategy

- **ArchUnit** — `ulos-common-lib`'s `ArchitectureComplianceTest` dengan rules baru (lihat Common-Lib Changes). `mvn -pl ulos-common-lib test` harus hijau.
- **Unit bpm-service** — `ProcessStartServiceTest` mock `RuntimeService`, verify call key + variables.
- **Contract test (Spring Cloud Contract)** — producer contract untuk `BPM_PROCESS_STATE_CHANGED`, consumer di orchestration.
- **Integration (Testcontainers)** — `BpmServiceIntegrationTest`: Postgres + Kafka + bpm-service, publish `ProcessStartRequestedEvent`, assert `runtimeService.createProcessInstanceQuery().count()==1` + outbound state event muncul.
- **E2E docker-compose smoke** — `POST /api/v1/applications` → poll `GET /api/v1/applications/{id}` sampai `processInstanceId` non-null (bukti round-trip via Kafka).

---

## Rollout Sequence

| Step | Action | Gate |
|---|---|---|
| 0 | Fix Flyway V2 collision di orchestration (rename salah satu) | Migration sukses di clean DB |
| a | Scaffold `ulos-bpm-service`, tambah ke root pom, empty main boots | `mvn install` hijau |
| b | Tambah common-lib DTOs + topic constants + ProcessVariableDto + update ArchUnit rules | ArchitectureComplianceTest hijau |
| c | COPY (jangan delete) Flowable code + delegates + BpmnDeploymentController ke bpm-service. Sementara kedua service run Flowable (orchestration schema=`flowable`, bpm-service schema=`flowable_v2` untuk parity test) | bpm-service start, expose `/api/v1/bpmn/**` port 8085 |
| d | Wire Kafka. Orchestration publish `ProcessStartRequestedEvent` via outbox TAPI tetap call `runtimeService` lokal (dual-write read mode). Verify bpm-service correctly start process dari Kafka | Integration test hijau; processInstanceId match |
| e | Flip switch: orchestration stop call `runtimeService`. Hanya bpm-service start process. Gateway route swing ke bpm-service | Smoke test hijau, no DLQ |
| f | Jalankan `V4__migrate_bpmn_deployment_data.sql` (kalau ada data). Lalu `V4__drop_orchestration_bpmn_deployment.sql` | Row count match di `flowable.tb_bpmn_deployment` |
| g | Delete Flowable code dari orchestration (lihat list). Remove flowable deps dari pom. Remove flowable yaml. Remove flowable datasource bean | orchestration build tanpa `org.flowable.*` imports; ArchUnit `orchestration MUST NOT depend on org.flowable` hijau |
| h | Update CLAUDE.md | PR di-approve semua squad |
| i | Prod cutover via feature flag, monitor Kafka lag 24 jam | No DLQ entry, lag < 100 |

---

## Critical Files to Modify

```
/Users/johanesjsitumorang/development/ulosv0/pom.xml                                                              (add module)
/Users/johanesjsitumorang/development/ulosv0/CLAUDE.md                                                            (squad, tree, anti-pattern)
/Users/johanesjsitumorang/development/ulosv0/docker-compose.yml                                                   (add bpm-service)
/Users/johanesjsitumorang/development/ulosv0/ulos-api-gateway/src/main/resources/application.yml                  (route /api/v1/bpmn/**)
/Users/johanesjsitumorang/development/ulosv0/ulos-common-lib/src/main/java/com/ulos/common/kafka/KafkaTopics.java (3 topic constants)
/Users/johanesjsitumorang/development/ulosv0/ulos-common-lib/src/main/java/com/ulos/common/dto/bpm/*.java         (3 event records + ProcessVariableDto)
/Users/johanesjsitumorang/development/ulosv0/ulos-common-lib/src/test/.../ArchitectureComplianceTest.java         (3 new rules)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/pom.xml                                   (remove flowable deps line 43-51)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/src/main/resources/application.yml        (remove flowable block 88-105)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/DataSourceConfig.java (remove flowable bean)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/src/main/java/com/ulos/orchestration/service/LoanOrchestrationService.java (replace runtimeService call with outbox publish)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/src/main/resources/db/migration/V2__add_bpmn_deployment_table.sql (collision fix + later drop)
/Users/johanesjsitumorang/development/ulosv0/ulos-orchestration-service/src/main/resources/db/migration/V2__create_rbac_tables.sql (collision fix)
```

---

## Verification (End-to-End)

1. **Build**: `mvn -pl ulos-bpm-service install`, `mvn -pl ulos-orchestration-service install`, `mvn -pl ulos-common-lib test` (ArchUnit) — semua hijau
2. **DB**: connect ke `ulos_orchestration`, jalankan `\dn` — pastikan schema `orchestration`, `flowable`, `audit` exist; `\dt flowable.*` lists `ACT_*` + `tb_bpmn_deployment` + `tb_outbox_event` + `tb_consumed_event`
3. **Boot**: `docker compose up postgres-orchestration kafka keycloak ulos-orchestration-service ulos-bpm-service` — kedua service healthy
4. **API smoke**:
   ```bash
   TOKEN=$(curl -s -X POST http://localhost:8080/realms/ulos/protocol/openid-connect/token -d 'grant_type=password&client_id=ulos-ui&username=tester&password=...' | jq -r .access_token)
   APP_ID=$(curl -s -X POST http://localhost:8000/api/loans/v1/applications -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d @sample.json | jq -r .data.id)
   sleep 5
   curl -s http://localhost:8000/api/loans/v1/applications/$APP_ID -H "Authorization: Bearer $TOKEN" | jq .data.processInstanceId
   # → harus non-null, bukti round-trip Kafka berfungsi
   ```
5. **Kafka inspect**: `kafka-console-consumer --topic ulos.bpm.process-start-requested --from-beginning` lihat event, lalu `ulos.bpm.process-state-changed` — keduanya harus ada untuk applicationId yang sama
6. **BPMN deploy**: `POST /api/v1/bpmn/deploy` via gateway — pastikan diroute ke bpm-service:8085 (cek log), record muncul di `flowable.tb_bpmn_deployment`
7. **Resilience**: matikan rule-service, submit application — circuit breaker open, fallback log muncul, message tidak hilang (di DLQ atau retry queue)
8. **Idempotency**: replay same Kafka event 2x — hanya 1 process instance dibuat (`tb_consumed_event` block duplicate)
9. **Observability**: `curl http://localhost:8085/actuator/prometheus | grep flowable` — Flowable metrics keluar; Zipkin UI tampilkan trace lintas orchestration → bpm-service

---

## Risks & Open Issues

1. **Flyway V2 collision di orchestration** — `V2__add_bpmn_deployment_table.sql` vs `V2__create_rbac_tables.sql`. Bug pre-existing. Harus rename salah satu jadi V2.1 atau geser. Cek `flyway_schema_history` di DB existing dulu.
2. **`ProcessVariableDto` belum ada di repo** meskipun CLAUDE.md menyebutkan. Wajib dibuat di common-lib sebagai bagian refactor ini.
3. **Order of events** — Kafka partition by `applicationId` jamin ordering per app, tapi orchestration consumer harus toleran terima `ProcessStateChangedEvent` untuk applicationId yang belum dikenal (race kalau outbox poll cepat) → buffer atau retry dengan delay.
4. **Outbox latency** — kalau poller bpm-service nge-lag, orchestration lihat status stale. Set poll interval 1 detik, SLO < 5 detik.
5. **Flowable async executor di multi-instance** — `ACT_RU_JOB` lock-based. Verify `flowable.async-executor-lock-time-in-millis` tuned untuk HA (default 5 menit).
6. **Virtual threads + Flowable** — Flowable 7.2 mungkin tidak full support `Thread.ofVirtual()` untuk async executor. Test sebelum enable di prod.
7. **Audit shared schema** — dua service tulis ke `audit.tb_audit_log` bersamaan. Pastikan tidak ada per-service constraint.
8. **Keycloak realm** — pastikan `ROLE_BPMN_DESIGNER` ada di realm + mapped ke bpm-service audience.
9. **BPMN bean lookup** — JavaDelegate harus tersedia di Spring context bpm-service dengan bean name SAMA. BPMN XML `${ruleEvaluationDelegate}` cari bean by name — kalau salah package atau salah `@Component("name")`, Flowable throw runtime error.
10. **`outbox/` di orchestration** — pastikan publisher hanya publish event jenis yang relevan (kalau ada event lain yang sebelumnya consume sendiri, tidak ikut ke bpm-service).
