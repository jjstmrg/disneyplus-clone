# Standardize Form Input Components, Validation & Multistep UI

## Context

Form input & validation handling tak konsisten di ulos-ui. Lead problem = dropdown, tapi merembet ke semua komponen input. Tiga "keluarga" komponen hidup paralel dengan token & a11y berbeda:

1. **UI primitives** `src/components/ui/`: `Input` & `Select` sudah standar (`danger-*`, red asterisk, `aria-invalid`/`role=alert`, `rounded-xl`) — hasil commit `f3905b3`. Tapi:
   - `Select` selalu render badge "LOV" walau tanpa `lovName`.
   - `Textarea` ketinggalan: tak ada `required`/asterisk/`aria-invalid`/`aria-describedby`/`role=alert`.
   - `Checkbox` tak punya prop `error`/`required` sama sekali.
   - `FormField` (legacy) pakai token `red-*`, tanpa aria.
2. **Portfolio RHF controls** `src/components/portfolio/FormControls.tsx`: `FormField`/`SelectField`/`CurrencyInput`/`RadioField` — reimplementasi sendiri, token **`red-*`**, `rounded-lg`, placeholder hardcode `-- Pilih --`, tanpa aria, tiap komponen mengulang loop ekstraksi error nested-path.
3. **RJSF dynamic** `src/components/dynamic-form/RjsfTheme.tsx`: `TailwindSelectWidget` border `danger-300` (shade beda) + placeholder `"Select an option"`; `BaseInputTemplate`/`CurrencyWidget`/`RadioWidget`/`CheckboxWidget` token agak beda.

Plus `wizard/AddressSection.tsx` punya 5 `<Select>` tanpa wiring validasi sama sekali, dan 3 framework validasi (RHF+zod, RJSF, manual) dengan pesan/timing berbeda.

**Tujuan** (keputusan user): satu set komponen + visual + a11y + pesan konsisten di SEMUA UI — dropdown sebagai pusat, plus semua input lain yang relevan. Framework validasi existing (RHF/zod, RJSF) **tetap**. Pesan i18n **terpusat**. Timing: **validate saat Submit/Next lalu live-revalidate**.

## Standar (kontrak tunggal)

Sumber kebenaran = primitives di `src/components/ui/`. Semua komponen lain render lewatnya atau menyamai token persis.

**Design tokens (sekali, dipakai semua):**
- Border normal `border-slate-200 bg-slate-50/50`, focus `ring-primary-100 border-primary-500`, radius `rounded-xl`.
- Error: border `danger-500/40`, bg `danger-50/30`, focus ring `danger-500/20`.
- Pesan error: `text-[11px] font-bold text-danger-600`, `role="alert"`, id terhubung `aria-describedby`.
- Label: `text-sm font-bold text-slate-700`; required → `*` `text-danger-500`.
- LOV badge: hanya saat `lovName`/lov ada.
- **Token `red-*` dilarang** untuk state error — selalu `danger-*`.

**A11y baseline (semua field input):** `aria-invalid` saat error, `aria-describedby` ke error/hint, error pakai `role="alert"`, label `htmlFor` terhubung.

**Pesan i18n terpusat:**
- Placeholder dropdown: `please_select` ("— Pilih —"/"— Select —").
- Wajib diisi/pilih: `field_required` (sudah ada).
- Banner/toast level-form: `please_complete_required` (sudah ada).
- Hapus semua string hardcode (`-- Pilih --`, `"Select an option"`, pesan validasi manual).

**Timing validasi:** error muncul saat Submit/Next; setelah attempt pertama → live-revalidate per field. RJSF `liveValidate={attempted}` (sudah). RHF set `reValidateMode: 'onChange'` setelah submit. Step manual simpan flag `attempted`.

## Perubahan

### A. UI primitives (`src/components/ui/`) — sumber kebenaran
1. **Shared field shell**: buat `FieldShell.tsx` (atau helper) = label + LOV badge + asterisk + slot error/hint dengan id+aria, agar `Input`/`Select`/`Textarea`/`Checkbox` pakai markup identik (hilangkan duplikasi & drift). Primitives bungkus children-nya dengan shell.
2. **`Select.tsx`**: badge LOV hanya saat `lovName`; sisanya pertahankan.
3. **`Textarea.tsx`**: tambah `required` + asterisk, `aria-invalid`, `aria-describedby`, error `id`+`role=alert` (samakan dgn Input).
4. **`Checkbox.tsx`**: tambah prop `error`/`required`; tampilkan asterisk di label + pesan error (role=alert).
5. **`Input.tsx`**: sudah standar; refactor ke FieldShell biar seragam (no behavior change).

### B. Portfolio RHF controls — delegasi ke primitives
`src/components/portfolio/FormControls.tsx`:
- `SelectField` → render `ui/Select` (`error`, `required`, `lovName`, `placeholder={t('please_select')}`).
- `FormField` (text/date/email/tel/number/textarea) → render `ui/Input`/`ui/Textarea`.
- `CurrencyInput` → render `ui/Input` (pertahankan logika format ribuan id-ID) + token `danger-*`.
- `RadioField` → samakan token error `danger-*` + aria.
- Ekstraksi error nested-path + `t(message)` dikumpulkan ke satu helper `useFieldError(errors, name, t)` (hapus loop berulang di tiap komponen).
- Buang semua `red-*`/`rounded-lg`/`-- Pilih --`. Konsumen otomatis ikut standar: `portfolio/steps/{FinancialInfoStep,DebtorInfoStep,ReviewStep}.tsx`, `wizard/AppSummaryStep.tsx`.

### C. RJSF dynamic — selaras token via primitives
`src/components/dynamic-form/RjsfTheme.tsx`:
- `TailwindSelectWidget` → render `ui/Select` (map `enumOptions`→`options`, `rawErrors`→`error`, `required`, placeholder `t('please_select')`).
- `BaseInputTemplate`/`CurrencyWidget` → samakan token ke `ui/Input` (border/bg/radius/placeholder).
- `RadioWidget`/`CheckboxWidget` → token error `danger-*` + asterisk lewat `FieldTemplate` (sudah `danger`), pastikan pesan `text-danger-600`.
- `TailwindFieldTemplate`: badge LOV hanya saat nama ada; pesan error `text-danger-600`.

### D. Wizard manual
- `wizard/AddressSection.tsx`: terima `errors` + `attempted` dari parent; pasang `error`/`required` ke 5 Select; pesan `t('field_required')`.
- `wizard/ApplicationInfo.tsx`: pastikan pesan `field_required` + live-revalidate setelah Next pertama.
- `pages/NewApplicationPage.tsx`: ganti string validasi manual hardcode → helper bersama; simpan flag `attempted`.

### E. Helper validasi bersama
- `src/lib/formValidation.ts` (baru) atau extend `src/lib/validation.ts`: `requiredSelect(value, t)`, `requiredField(value, t)` → `t('field_required')` saat kosong; util kumpul `Record<string,string>` errors. Dipakai step manual + `NewApplicationPage.goNext`.

### F. i18n & legacy
- `src/locales/translations.ts`: tambah `please_select` (ID/EN); hapus hardcode; reuse `field_required`/`please_complete_required`.
- `src/components/ui/FormField.tsx` (legacy `red-*`): audit pemakaian; jika tak terpakai → hapus; jika terpakai → migrasi ke `ui/Input`/`ui/Select`. (Catatan: step portfolio import `FormField` dari **FormControls**, bukan ui/FormField — bedakan.)

### G. Multistep UI — komponen stepper bersama
Dua flow multistep (loan application `NewApplicationPage` + portfolio `NewPortfolioPage`) meng-copy markup pill-stepper nyaris identik tapi reimplementasi terpisah. Divergensi: label tombol (`next/prev/submit_app` vs `next_tab/prev_tab/save_finish`), posisi tombol (space-between vs right-aligned), warna tombol final (`bg-slate-900` vs `bg-success-600`), ikon completed (`Check` vs `CheckCircle`), state (Zustand vs `useState`), progress % (hanya app), animasi (slide vs fade), draft (hanya portfolio).

Buat komponen bersama di `src/components/ui/`:
1. **`Stepper.tsx`** — pill-stepper indikator. Props: `steps: {id, label, icon}[]`, `currentStep`, `maxReachedStep`, `onStepClick`, `completedIcon?`. Token: active `bg-primary-600 text-white shadow-md`, completed `bg-primary-50 text-primary-700`, future `bg-slate-50 text-slate-300`, label `hidden sm:inline`. Klik hanya step `<= maxReachedStep`.
2. **`StepperNav.tsx`** — baris tombol Back/Next/Submit. Props: `isFirst`, `isLast`, `loading`, `onBack`, `onNext`, `onSubmit`, label opsional (default i18n). Layout konsisten (Back kiri, Next/Submit kanan), tombol final 1 warna standar (pilih `success-600` atau `primary-700` — samakan).
3. **i18n nav terpadu**: satu set key `step_next`/`step_prev`/`step_submit` (alias dari `next`/`prev`); hentikan duplikat `next_tab`/`prev_tab`. Step title boleh tetap per-flow.
4. **Kontrak gating seragam**: tiap flow sediakan `validateStep(index) => Promise<boolean>`; `StepperNav.onNext` panggil itu, blok kalau gagal + tampil banner `please_complete_required`, lalu live-revalidate (selaras bagian D). State step tetap per-flow (Zustand/useState) — komponen stepper presentational.
5. Refactor `NewApplicationPage.tsx` + `NewPortfolioPage.tsx` (dan step portfolio/wizard) pakai `Stepper`+`StepperNav`; buang ~80 baris markup duplikat. Draft & progress% tetap opsional per-flow (slot/prop).

## File kunci
- `src/components/ui/`: `FieldShell.tsx` (baru), `Stepper.tsx` (baru), `StepperNav.tsx` (baru), `Select.tsx`, `Textarea.tsx`, `Checkbox.tsx`, `Input.tsx`, (opsional) `FormField.tsx`
- `src/components/portfolio/FormControls.tsx` + `portfolio/steps/*`
- `src/components/dynamic-form/RjsfTheme.tsx`
- `src/components/wizard/AddressSection.tsx`, `ApplicationInfo.tsx`
- `src/pages/NewApplicationPage.tsx`, `src/pages/NewPortfolioPage.tsx`
- `src/lib/formValidation.ts` (baru) / `src/lib/validation.ts`
- `src/locales/translations.ts`

## Verifikasi
1. `npx tsc --noEmit` bersih.
2. Vitest: `Select.test`/`Input.test` tetap hijau; tambah test — Select badge tersembunyi tanpa `lovName`; `Textarea`/`Checkbox` set `aria-invalid`+`role=alert` saat error; `SelectField` tampil error RHF + asterisk.
3. Manual E2E (mock on), bandingkan 3 jenis form (wizard manual, portfolio RHF/zod, RJSF dynamic):
   - Kosongkan field wajib → Submit/Next → border `danger-*` + asterisk + inline `field_required` + banner; AddressSection kini validasi; ubah field setelah attempt → error hilang live.
   - Placeholder dropdown seragam "— Pilih —"; semua input pakai `rounded-xl` + token `danger-*`; tak ada lagi `red-*`/`-- Pilih --`/"Select an option".
4. Cek a11y: `aria-invalid`/`aria-describedby`/`role=alert` ada di Input/Select/Textarea/Checkbox.
5. Visual parity lintas 3 jenis form (warna/asterisk/placeholder/radius/aria sama).
6. Multistep: kedua flow (application + portfolio) render via `Stepper`+`StepperNav` — indikator/tombol/label/warna final identik; gating blok Next saat invalid + banner; klik step terbatas `<= maxReached`; draft & progress% tetap jalan.

## Catatan scope
Refactor luas tapi mayoritas mekanis (delegasi + ganti token + ekstrak komponen). Tanpa migrasi framework validasi (RHF/zod & RJSF dipertahankan); state step tetap per-flow. Urutan bertahap: (1) primitives + FieldShell (fondasi), (2) FormControls delegasi, (3) RJSF token, (4) wizard + helper validasi, (5) i18n, (6) Stepper/StepperNav + refactor 2 flow.
