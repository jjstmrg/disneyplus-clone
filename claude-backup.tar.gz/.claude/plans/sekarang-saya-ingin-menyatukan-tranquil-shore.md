# Phase 0 — Access Control ULOS (Halaman Login TIDAK Disentuh)

## Context

Review RBAC menemukan: permission di-resolve gateway via REST ke iam-service lalu **tidak masuk JWT** → service backend tidak pernah terima permission → RBAC granular hanya kosmetik UI. Tiga vocabulary permission divergen (gateway hardcoded / iam DB seed / UI menuConfig); menu `/approvals` tidak terjangkau siapa pun; ROLE_ADMIN + ROLE_VIEWER tidak di-seed.

User memilih sequencing aman: **Phase 0 = bangun access control dulu, halaman login dibiarkan apa adanya**; perubahan flow login (redirect ke Keycloak) ditunda ke Phase 1. Alasan: rewrite login adalah perubahan paling berisiko — diisolasi ke belakang.

Kunci teknis: **cara login (ROPC vs redirect) dan cara permission dikirim (respons login vs JWT) itu independen.** Isi token JWT Keycloak sama apa pun grant type-nya. Maka permission bisa dimasukkan ke JWT **tanpa menyentuh halaman login**.

## Scope

**Phase 0 (sekarang) — Access Control:**
- Permission masuk JWT (client role Keycloak + protocol mapper).
- Backend `@PreAuthorize` per endpoint — enforcement nyata.
- UI: perbaiki vocabulary permission, perbaiki bug `/approvals`, tambah `<Can>` untuk tombol/hyperlink.
- Perbaiki gap seed role (ROLE_ADMIN, ROLE_VIEWER).
- **Halaman login `LoginPage.tsx` + flow ROPC: NOL perubahan.**

**Phase 1 (nanti) — Auth Flow Hardening:**
- ROPC → Authorization Code + PKCE (redirect ke Keycloak).
- LDAP/AD user federation.
- Tema halaman login Keycloak / Hybrid.
- MFA (toggle Keycloak).
- iam-service jadi admin facade + maker-checker + rewire menu Security.
- Drop tabel `rbac_*`.

## Yang DISENTUH vs TIDAK (Phase 0)

| | Status |
|---|---|
| `LoginPage.tsx` | **TIDAK disentuh** |
| Flow login (form → gateway → ROPC) | **TIDAK disentuh** |
| Keycloak config (client role, mapper) | disentuh |
| Gateway (berhenti panggil iam, baca JWT) | disentuh — kecil, `/login` ROPC tetap |
| common-security converter | disentuh |
| Backend controller (`@PreAuthorize`) | disentuh |
| UI menuConfig / `<Can>` / route guard | disentuh |

## Keputusan terkunci

| Topik | Keputusan |
|---|---|
| Sequencing | Phase 0 access control dulu, Phase 1 login flow (usulan user) |
| Halaman login Phase 0 | Tetap `LoginPage.tsx` existing, ROPC, tanpa redirect |
| Representasi permission | Keycloak **client role**; composite realm role agregasi; masuk JWT via `resource_access` |
| Sumber permission | JWT (single source) — gateway berhenti panggil iam-service `/rbac/permissions` |
| iam-service `rbac_*` | Dorman di Phase 0; refactor facade = Phase 1 |
| MFA | Off |

## Risk register

ROPC masih dipakai selama Phase 0. **OK hanya jika** Phase 0 belum produksi (pilot/non-prod) DAN Phase 1 (Auth Code + PKCE) mendarat sebelum go-live produksi. Catat sebagai item remediasi terjadwal — sama logikanya dengan penundaan MFA.

## Perubahan per komponen (Phase 0)

### 1. Keycloak — `infra/keycloak/realm-export.json`
- Tambah **client role = permission** pada client `ulos-backend` (baru) atau reuse `ulos-ui`: `loan:create`, `loan:view`, `loan:approve`, `loan:reject`, `approval-queue:view`, `portfolio:view`, `security:manage`, `bpmn:deploy` — vocabulary permission kanonik tunggal.
- Composite realm role agregasi client role:
  - ROLE_MAKER → `loan:create`, `loan:view`
  - ROLE_CHECKER → `loan:view`, `loan:approve`, `loan:reject`, `approval-queue:view`
  - ROLE_VIEWER → `loan:view`, `portfolio:view`
  - ROLE_ADMIN → semua (**perbaiki gap** — ROLE_ADMIN + ROLE_VIEWER kini punya mapping)
- Client role otomatis muncul di token via `resource_access.{client}.roles` — converter sudah baca ini. (Opsional: protocol mapper flatten ke claim `permissions` untuk kemudahan UI.)
- `directAccessGrantsEnabled` pada `ulos-gateway-client` **TETAP true** di Phase 0 (ROPC masih dipakai). Dimatikan di Phase 1.

### 2. Gateway — `ulos-api-gateway`
`controller/GatewayAuthController.java`:
- `/login`, `/refresh`, `/logout` ROPC → **tetap apa adanya**.
- `fetchUserInfo` — hapus pemanggilan iam-service `/api/v1/rbac/permissions`. Permission diambil dari JWT (token sudah di tangan). Single source.
- `extractRolesFromToken` — boleh tetap di Phase 0 (berfungsi); diganti `JwtDecoder` resmi di Phase 1.
- **Hapus** `service/PermissionMappingService.java` (dead code).

### 3. common-security — `ulos-common-security`
- **Pindahkan** `KeycloakJwtAuthenticationConverter` ke `ulos-common-security` (kini diduplikasi di `ulos-orchestration-service` + `ulos-bpm-service`).
- Refine: realm role → prefix `ROLE_`; client role (permission) → authority polos tanpa prefix → `@PreAuthorize("hasAuthority('loan:approve')")` bersih.
- `ulos-orchestration-service` + `ulos-bpm-service` — hapus copy lokal, pakai common-security.

### 4. Backend service — endpoint enforcement
- Tambah `@PreAuthorize("hasAuthority('<permission>')")` pada endpoint di balik fitur ber-RBAC: approval queue, BPMN deploy, security/admin, create/approve loan.
- Tes per endpoint: tanpa permission → 403, dengan → 200.

### 5. UI — `ulos-ui`
- `src/config/menuConfig.tsx` — selaraskan string `permission` ke vocabulary Keycloak (mis. `/approvals` → `approval-queue:view` yang kini benar-benar ada). Tambah `permission` untuk `/security` (`security:manage`) + `/admin/bpmn-deploy` (`bpmn:deploy`).
- `src/App.tsx` — `requiredPermission` route guard selaras vocabulary.
- `src/components/security/Can.tsx` (baru) — komponen `<Can permission="...">` bungkus tombol/hyperlink/komponen.
- `src/hooks/usePermission.ts` — pastikan baca permission konsisten (dari `user.permissions` respons login yang kini di-derive dari JWT, ATAU decode JWT langsung).

### 6. iam-service — `ulos-iam-service`
- `/api/v1/rbac/permissions` tidak terpakai (gateway berhenti panggil). Service tetap deploy, dorman. Tabel `rbac_*` tidak disentuh. Refactor facade = Phase 1.

## File yang disentuh (Phase 0)

| File | Aksi |
|---|---|
| `docs/adr/0004-rbac-auth-architecture.md` | baru — ADR keputusan + scope Phase 0/1 + koreksi ADR 0003 (hard-gate schema `iam` jadi DB terpisah di prod) |
| `infra/keycloak/realm-export.json` | edit — client role, composite, perbaiki seed |
| `ulos-api-gateway/.../controller/GatewayAuthController.java` | edit — buang call iam, baca JWT |
| `ulos-api-gateway/.../service/PermissionMappingService.java` | hapus |
| `ulos-common-security/.../KeycloakJwtAuthenticationConverter.java` | baru (dipindah) |
| `ulos-common-security/.../BaseSecurityConfig.java` | edit — wire converter |
| `ulos-orchestration-service/.../config/KeycloakJwtAuthenticationConverter.java` | hapus |
| `ulos-bpm-service/.../config/KeycloakJwtAuthenticationConverter.java` | hapus |
| Backend controller (orchestration, bpm, rule, integration) | edit — tambah `@PreAuthorize` |
| `ulos-ui/src/config/menuConfig.tsx` | edit — vocabulary |
| `ulos-ui/src/App.tsx` | edit — route guard vocabulary |
| `ulos-ui/src/components/security/Can.tsx` | baru |
| `ulos-ui/src/hooks/usePermission.ts` | edit |

## Langkah eksekusi

1. Tulis `docs/adr/0004-rbac-auth-architecture.md`.
2. Update `realm-export.json` — client role, composite, perbaiki seed role.
3. common-security — buat converter, hapus dua copy lokal, wire `BaseSecurityConfig`.
4. Gateway — buang call iam + `PermissionMappingService`; `/login` ROPC tetap.
5. Backend — tambah `@PreAuthorize` per endpoint.
6. UI — `Can.tsx`, selaraskan `menuConfig` + route guard + `usePermission`.
7. Verifikasi end-to-end.

## Verifikasi end-to-end (Phase 0)

| Cek | Cara | Harapan |
|---|---|---|
| Login tidak berubah | Login lewat `LoginPage.tsx` existing | Sama persis seperti sekarang |
| Permission di JWT | Decode access token hasil login | Berisi client role / claim permission |
| Backend enforce | Panggil endpoint approval tanpa permission | 403; dengan permission → 200 |
| Menu `/approvals` | Login ROLE_CHECKER | Menu Approval Queue muncul + bisa diakses (bug lama beres) |
| ROLE_ADMIN | Login admin01 | Lihat semua menu (gap seed beres) |
| Komponen `<Can>` | Login ROLE_MAKER | Tombol Approve tersembunyi; ROLE_CHECKER → tampil |
| Converter | `@PreAuthorize` service | Authority `ROLE_*` (realm) + permission polos (client) |

## Catatan

- Phase 0 menghasilkan access control **nyata** (UI + backend) dengan satu vocabulary permission. Halaman login aman, tidak disentuh.
- Phase 1 (redirect Auth Code + PKCE, LDAP, tema) jadi perubahan terisolasi — RBAC sudah jadi & tidak bergantung padanya.
- iam-service + `rbac_*` dorman — keputusan facade/maker-checker di Phase 1.
