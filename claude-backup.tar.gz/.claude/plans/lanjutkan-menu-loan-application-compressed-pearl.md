# Plan — Collapsible Workflow History on Loan Detail

## Context

Loan Application detail page (`ApplicationDetailPage.tsx`) feels cramped. Two
causes:

1. **Layout splits width 2/3 + 1/3.** `grid lg:grid-cols-3` — tab content is
   locked to `lg:col-span-2`; the Workflow History panel always occupies the
   remaining 1/3 and cannot be hidden.
2. **Tab strip overflows.** 6 tabs (Summary / Customer / Facility / Collateral /
   Document / Dashboard Checking) inside the narrowed 2/3 column overflow
   horizontally; `Tabs.tsx` has `overflow-x-auto`, so the user must scroll the
   strip sideways to reach the later tabs.

Goal: let the user **show/hide** the Workflow History panel. When hidden, the
tabbed content takes the **full page width** — tabs fit on one row, no sideways
scrolling — and the detail view no longer looks small.

## Change — `ulos-ui` only (🟦 Frontend squad)

Single file: `ulos-ui/src/pages/ApplicationDetailPage.tsx`.

### 1. Widen the page container
- `max-w-6xl` → `max-w-7xl` (line 98) for more breathing room overall.

### 2. Collapse state
- Add `const [historyOpen, setHistoryOpen] = useState(true)`.
- Persist preference in `localStorage` key `ulos.detail.historyOpen` (lazy
  initializer reads it, `useEffect` writes on change) so the choice sticks
  across navigations. Default = open.

### 3. Responsive grid driven by state (lines 121-144)
- Outer grid: when `historyOpen` → `lg:grid-cols-3`; when closed →
  `lg:grid-cols-1` (single column, full width).
- Left content div: `historyOpen ? 'lg:col-span-2' : ''`.
- Right Workflow History panel: render only when `historyOpen`.

### 4. Toggle control
- Add a show/hide button. Render the existing `Tabs` and the toggle button
  side by side in a `flex items-center justify-between gap-2` wrapper, so the
  button sits at the right edge and stays visible regardless of tab scroll.
- Button uses `Button` from `@/components/ui` (`variant="ghost"`, `size="sm"`)
  with a `lucide-react` icon: `PanelRightClose` when open, `PanelRightOpen`
  when closed. Label respects `isID`:
  - open  → `Sembunyikan Riwayat` / `Hide History`
  - closed → `Tampilkan Riwayat` / `Show History`
- `aria-expanded={historyOpen}` on the button for accessibility.

No new component, no API change, no backend change. `Tabs.tsx` stays as-is —
its `overflow-x-auto` remains the safety net for very small screens, but at
full width the 6 tabs fit without scrolling.

## Critical file

- `ulos-ui/src/pages/ApplicationDetailPage.tsx` — only file modified.
- Reuses: `Button` from `@/components/ui` (already exported, `index.ts:4`),
  `lucide-react` icons (already a dependency).

## Verification

1. `cd ulos-ui && npm run dev` → open a loan detail (`/applications/:id`) from
   the Loan Application list.
2. Workflow History panel visible by default; click **Hide History** → panel
   disappears, tabbed content expands to full width, all 6 tabs visible on one
   row with no horizontal scroll.
3. Click **Show History** → panel returns, layout back to 2/3 + 1/3.
4. Reload page → collapse state persists (localStorage).
5. Resize to mobile width → still single column, no regression.
6. `npm test && npm run lint` green; `tsc` clean for this file.
