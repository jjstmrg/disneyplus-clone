# Plan: Backend Parameter Management (Maker-Checker)

## Context

The ULOS frontend already ships a complete **Parameter Management** feature
(`ParameterListPage`, `ParameterDetailPage`, `parameterApi.ts`, `useLov` hooks,
`useParameterStore`) but runs entirely on a mock layer — `PARAMETER_USE_MOCK = true`
because *"the parameter backend does not exist yet"* (quote from `parameterApi.ts:20`).

"Parameter" = reference / master data:
- **LOV** — List of Values, dropdown options consumed by the loan wizard (gender, customer type, tenor…).
- **PRODUCT** — loan product config (KI / PRK, interest rate, min/max amount) in item `metadata`.
- **CONFIG** — single-value system config (max loan amount…).
- **OTHERS** — misc.

This plan builds that backend with three hard requirements:

1. **Maker-checker (4-eyes)** — a change to a governed parameter (header *and* items) is
   staged as a change request; a different user must approve before it goes live.
2. **Configurable maker-checker** — a global on/off switch, plus a per-parameter
   `requiresApproval` flag, so only changes that actually need approval are staged.
3. **No consumer performance impact** — code paths that *read* parameters (loan wizard
   dropdowns, future rule/bpm consumers) must not pay for maker-checker overhead.

**Decisions (confirmed with user):**
- Host service: **`ulos-orchestration-service`** — `parameterApi.ts:16` already declares it,
  and parameters are loan-domain reference data. No Flowable involved, so the "NO Flowable"
  rule is respected.
- Approval scope: **all changes** — header create/update + item create/update/delete.
- Maker-checker is **configurable** — a global on/off switch + a per-parameter
  `requiresApproval` flag. A mutation is staged only when `globalEnabled && requiresApproval`;
  otherwise it is applied directly. Every mutation is still recorded in one audit table.
- Read path: **Redis cache only** — no Kafka (rationale in its own section below).
- Frontend: **backend + minimal frontend** (wire real API, add a checker approvals panel
  and the maker-checker config controls).

---

## Architecture — read/write separation + approval gate

Every mutation passes an **approval gate**, then either stages a change request or applies
directly. Consumer reads only ever hit the **live tables**:

```
                   ┌─ gate: makerCheckerEnabled && parameter.requiresApproval ?
                   │
MAKER ──mutate──▶───┤── YES ─▶ tb_parameter_change_request (PENDING_APPROVAL)
                   │                       │
                   │         CHECKER ──approve──▶ apply payload
                   │                       │
                   └── NO ──▶ apply payload directly (request row → AUTO_APPLIED)
                                            │
                                            ▼
                         tb_parameter / tb_parameter_item  (LIVE)  + Redis evict
                                            │
CONSUMER (GET /parameters) ──reads ONLY─────┘  (Redis-cached, small + indexed)
```

Consumer reads **never touch** `tb_parameter_change_request`. No matter how many pending
requests pile up, read cost stays O(small live set) and is served from Redis. Every
mutation — staged *or* direct — is written to `tb_parameter_change_request`, so that table
is the complete parameter audit trail regardless of the maker-checker setting.

---

## Data model — `ulos-orchestration-service` (schema `orchestration`)

New migration **`V4__create_parameter_tables.sql`** (current highest = V3).

### `tb_parameter` — live header (consumer read path)
| column | type | notes |
|---|---|---|
| id | UUID PK | `BaseEntity` |
| param_code | VARCHAR(64) UNIQUE NOT NULL | regex `^[A-Z][A-Z0-9_]*$`, immutable |
| name | VARCHAR(255) NOT NULL | |
| description | TEXT | |
| category | VARCHAR(16) NOT NULL | LOV / PRODUCT / CONFIG / OTHERS |
| item_count | INT NOT NULL DEFAULT 0 | denormalized |
| active | BOOLEAN NOT NULL DEFAULT true | |
| requires_approval | BOOLEAN NOT NULL DEFAULT true | per-parameter maker-checker flag |
| version, created_by, created_date, modified_by, modified_date, deleted | | `BaseEntity` cols |

Index on `category`. Soft delete via `@SQLDelete` + `@SQLRestriction` (pattern from `LoanApplicationEntity`).

### `tb_parameter_item` — live items (consumer read path)
| column | type | notes |
|---|---|---|
| id | UUID PK | |
| parameter_id | UUID NOT NULL FK → tb_parameter(id) | |
| item_value | VARCHAR(128) NOT NULL | frontend `value`, immutable after create |
| label_id | VARCHAR(255) NOT NULL | Indonesian label |
| label_en | VARCHAR(255) NOT NULL | English label |
| description | TEXT | |
| sort_order | INT NOT NULL DEFAULT 0 | |
| active | BOOLEAN NOT NULL DEFAULT true | item soft-delete flag (frontend semantics) |
| metadata | JSONB | PRODUCT extras |
| `BaseEntity` cols | | |

`UNIQUE (parameter_id, item_value)`, index on `parameter_id`.

### `tb_parameter_change_request` — maker-checker staging (NOT on read path)
| column | type | notes |
|---|---|---|
| id | UUID PK | |
| request_type | VARCHAR(24) NOT NULL | CREATE_PARAMETER / UPDATE_PARAMETER / CREATE_ITEM / UPDATE_ITEM / DELETE_ITEM |
| target_param_code | VARCHAR(64) NOT NULL | |
| target_item_id | UUID | nullable, for item ops |
| payload_json | JSONB | desired new state |
| status | VARCHAR(16) NOT NULL | PENDING_APPROVAL / APPROVED / REJECTED / AUTO_APPLIED |
| maker_comment | TEXT | |
| checker_username | VARCHAR(100) | filled on decision |
| checker_comment | TEXT | required on reject |
| decided_at | TIMESTAMPTZ | |
| `BaseEntity` cols | | `created_by` = maker username, `created_date` = submit time |

Index on `status`. This table also **is** the parameter audit trail (who/what/when/decision).
A row with status `AUTO_APPLIED` (checker_username = `SYSTEM`) records a mutation that
skipped maker-checker because the approval gate said approval was not required.

### `tb_parameter_setting` — global maker-checker switch (single row)
| column | type | notes |
|---|---|---|
| id | UUID PK | |
| maker_checker_enabled | BOOLEAN NOT NULL DEFAULT true | global on/off |
| `BaseEntity` cols | | `modified_by` / `modified_date` track who toggled it |

Exactly one row, seeded in `V5`. Read on every mutation; tiny, cached in Redis alongside
parameters.

Migration **`V5__seed_parameters.sql`** — seed the single `tb_parameter_setting` row, then
seed the existing LOV / PRODUCT / CONFIG data
(at minimum the 8 `HOT_LOVS` from `useParameterStore.ts` + their items) by copying values
from `ulos-ui/src/api/mockData.ts`, so loan-wizard dropdowns keep working after mock is
switched off. Seed rows go straight to live tables (system bootstrap, bypasses maker-checker).

---

## Backend components — `com.ulos.orchestration` (hexagonal layout)

**`domain/parameter/`**
- `ParameterEntity`, `ParameterItemEntity`, `ParameterChangeRequestEntity`,
  `ParameterSettingEntity` — all `extends BaseEntity`.
- Enums: `ParameterCategory`, `ChangeRequestType`, `ChangeRequestStatus`.
- `ParameterRepository` (`findByParamCode`, `existsByParamCode`, `findByCategory`),
  `ParameterItemRepository` (`findByParameterId`, `findByParameterIdAndItemValue`),
  `ParameterChangeRequestRepository` (`findByStatus`, pending-duplicate check),
  `ParameterSettingRepository` (single-row fetch).

**`service/`** (interface + `Impl`, per convention)
- `ParameterQueryService` — **read path**. `listParameters(category)`, `getParameter(code)`,
  `getItems(code)`. `@Transactional(readOnly = true)` + `@Cacheable` (see Caching).
- `ParameterChangeRequestService` — **mutation + maker-checker path**:
  - Maker: `submitCreateParameter`, `submitUpdateParameter`, `submitCreateItem`,
    `submitUpdateItem`, `submitDeleteItem`. Each builds a change request row, then consults
    the **approval gate** — `makerCheckerEnabled && parameter.requiresApproval`:
    gate ON → leave it `PENDING_APPROVAL` (return 202); gate OFF → apply the payload
    immediately, set status `AUTO_APPLIED`, checker = `SYSTEM` (return 200).
    For `CREATE_PARAMETER` the parameter does not exist yet, so the gate uses
    `makerCheckerEnabled` alone. Maker username from
    `SecurityContextUtil.getCurrentUsername()` (auto via `@CreatedBy`).
  - Checker: `listChangeRequests(status)`, `getChangeRequest(id)`,
    `approve(id, comment)`, `reject(id, comment)`.
  - `approve` does, in one `@Transactional` block: re-validate → apply payload to live
    tables → set status APPROVED / checker / decided_at; cache evict on success.
- `ParameterSettingService` — `getSetting()`, `updateSetting(enabled)` (global toggle),
  `updateApprovalPolicy(code, requiresApproval)` (per-parameter flag). Both writes apply
  directly (no staging — governance config, not data) and evict the parameter cache.

**`adapter/inbound/ParameterController.java`** — base `/api/v1/parameters`, DTO `record`s
in `adapter/inbound/dto/` (`CreateParameterRequest`, `UpdateParameterRequest`,
`CreateLovItemRequest`, `UpdateLovItemRequest`, `ParameterResponse` — includes
`requiresApproval`, `LovItemResponse`, `ChangeRequestResponse`, `DecisionRequest`,
`ParameterSettingResponse`, `UpdateSettingRequest`, `ApprovalPolicyRequest`). A mutation
returns `ChangeRequestResponse` — **202 Accepted** when staged (`PENDING_APPROVAL`),
**200 OK** when applied directly (`AUTO_APPLIED`).

**`config/CacheConfig.java`** — Redis cache (see Caching).

**Reuse:** `BaseEntity` (audit cols auto-filled), `ApiResponse<T>`, `BusinessException` +
`GlobalExceptionHandler`, `SecurityContextUtil`.

### Endpoints

| Method | Path | Permission | Returns |
|---|---|---|---|
| GET | `/api/v1/parameters?category=` | `parameter:view` | `ParameterResponse[]` (cached) |
| GET | `/api/v1/parameters/{code}` | `parameter:view` | `ParameterResponse` (cached) |
| GET | `/api/v1/parameters/{code}/items` | `parameter:view` | `LovItemResponse[]` (cached) |
| POST | `/api/v1/parameters` | `parameter:manage` | 200/202 `ChangeRequestResponse` |
| PATCH | `/api/v1/parameters/{code}` | `parameter:manage` | 200/202 `ChangeRequestResponse` |
| POST | `/api/v1/parameters/{code}/items` | `parameter:manage` | 200/202 `ChangeRequestResponse` |
| PATCH | `/api/v1/parameters/{code}/items/{id}` | `parameter:manage` | 200/202 `ChangeRequestResponse` |
| DELETE | `/api/v1/parameters/{code}/items/{id}` | `parameter:manage` | 200/202 `ChangeRequestResponse` |
| GET | `/api/v1/parameters/change-requests?status=` | `parameter:approve` or `parameter:manage` | `ChangeRequestResponse[]` |
| GET | `/api/v1/parameters/change-requests/{id}` | `parameter:approve` or `parameter:manage` | `ChangeRequestResponse` |
| POST | `/api/v1/parameters/change-requests/{id}/approve` | `parameter:approve` | `ChangeRequestResponse` |
| POST | `/api/v1/parameters/change-requests/{id}/reject` | `parameter:approve` | `ChangeRequestResponse` |
| GET | `/api/v1/parameters/settings` | `parameter:view` | `ParameterSettingResponse` |
| PUT | `/api/v1/parameters/settings` | `parameter:approve` | `ParameterSettingResponse` |
| PUT | `/api/v1/parameters/{code}/approval-policy` | `parameter:approve` | `ParameterResponse` |

`change-requests` and `settings` are literal segments — Spring matches them before `{code}`,
and a valid `param_code` (uppercase) can never equal a lowercase literal, so no routing
collision. `/{code}/approval-policy` sits under a `{code}` path and is unambiguous.

### 4-eyes enforcement
`approve()` throws `BusinessException` ("Maker tidak boleh menyetujui perubahan sendiri")
when `changeRequest.createdBy.equals(SecurityContextUtil.getCurrentUsername())`.

### Apply logic (on approve)
- CREATE_PARAMETER → insert `tb_parameter` (item_count=0, active=true).
- UPDATE_PARAMETER → update name/description/active by code.
- CREATE_ITEM → insert `tb_parameter_item`, `parameter.item_count++`.
- UPDATE_ITEM → update label/description/sort_order/active/metadata by id (`item_value` immutable).
- DELETE_ITEM → set `item.active = false` (soft delete, frontend semantics).

### Validation
- Submit time (fast feedback): code regex, category enum, code uniqueness, item value
  uniqueness within parameter, reject if a `PENDING_APPROVAL` request already targets the
  same parameter/item.
- Approve time (correctness): re-validate against current live state; on conflict throw
  `BusinessException` so the checker sees a clear error instead of corrupting data.

---

## Caching — Redis (consumer performance)

`ulos-orchestration-service/pom.xml`: add `spring-boot-starter-data-redis` +
`spring-boot-starter-cache` (Redis runs in `docker-compose`, currently only used by gateway).

`config/CacheConfig.java`: `@EnableCaching` + `RedisCacheManager`, cache `ulos:parameters`,
TTL ~30 min (backstop), JSON value serializer.

`ParameterQueryService` read methods → `@Cacheable("ulos:parameters")` keyed by
`all` / `cat::{category}` / `code::{code}` / `items::{code}`.

On approve apply → `@CacheEvict(value = "ulos:parameters", allEntries = true)` — parameter
changes are rare, so a full evict is simplest and safe.

`application.yml` + `application-dev.yml` / docker profile: `spring.data.redis.host/port`
via `REDIS_HOST` / `REDIS_PORT` env (default `localhost:6379`).

---

## No Kafka — why, and how future consumers stay fresh

Kafka invalidation is **deliberately not used**. It would only matter if another backend
service kept its *own local cache* of parameters — and today none do (rule-service uses
DMN XML; bpm delegates read process variables). Publishing to a topic with no consumer is
dead infrastructure (YAGNI), plus an unused producer to wire and test.

The performance requirement is fully met by **Redis + read/write table separation alone**:
- The only consumer today is the frontend → `GET /api/v1/parameters` → served from Redis,
  evicted in-process the moment a change request is approved. Always fast, always fresh.

When a future backend service needs parameters, the simplest correct option is to
**Feign-call orchestration's Redis-cached GET endpoint** — no local cache, so no
invalidation problem at all, and still fast because orchestration serves from Redis. A
push-based Kafka invalidation can be added later *only if* some consumer adopts a local
cache — that is an additive change, not a rewrite.

---

## RBAC permissions — `ulos-iam-service` (schema `iam`)

New migration **`V5__add_parameter_permissions.sql`** (current highest = V4), following the
pattern of `V2__add_portfolio_permissions.sql` / `V3__add_application_detail_permissions.sql`:
- `parameter:view` — read parameters + read the maker-checker setting (loan officers + admins).
- `parameter:manage` — maker: submit mutations.
- `parameter:approve` — checker: approve/reject change requests, **and** toggle the global
  maker-checker switch + set the per-parameter `requiresApproval` policy.
Assign to roles per existing seed convention (admin gets all; `manage` and `approve`
to **different** roles so 4-eyes is enforceable organizationally).

Same squad (Backend Service owns both orchestration-service and iam-service) — one PR is fine.

---

## Frontend — minimal wiring (`ulos-ui`)

- **`src/types/parameter.ts`** — add `ParameterChangeRequest`, `ChangeRequestStatus`
  (`PENDING_APPROVAL` | `APPROVED` | `REJECTED` | `AUTO_APPLIED`), `ChangeRequestType`,
  `ParameterSetting`; add `requiresApproval: boolean` to `Parameter`.
- **`src/api/parameterApi.ts`** — set `PARAMETER_USE_MOCK = false`; mutation functions
  (`createParameter`, `updateParameter`, `createItem`, `updateItem`, `deleteItem`) now
  resolve to `ParameterChangeRequest`; add `listChangeRequests(status?)`,
  `getChangeRequest(id)`, `approveChangeRequest(id, comment?)`,
  `rejectChangeRequest(id, comment)`, `getSettings()`, `updateSettings(enabled)`,
  `updateApprovalPolicy(code, requiresApproval)`.
- **`src/components/parameter/`** — mutation modals: toast by result `status` —
  `PENDING_APPROVAL` → *"Diajukan untuk persetujuan"*, `AUTO_APPLIED` → *"Perubahan
  disimpan"*; drop optimistic insert. Add a `ChangeRequestPanel` (uses `@/components/ui`)
  listing `PENDING_APPROVAL` requests with Approve / Reject (reject opens a comment modal),
  gated `<Can perform="parameter:approve">`. Add a `MakerCheckerSettings` control — global
  on/off switch, gated `<Can perform="parameter:approve">`.
- **`src/pages/ParameterListPage.tsx`** — add a "Pending Approval" tab/section rendering
  `ChangeRequestPanel`, and surface the global maker-checker switch.
- **`src/pages/ParameterDetailPage.tsx`** — show the parameter's `requiresApproval` state
  with a toggle, gated `<Can perform="parameter:approve">`.
- **`src/store/useParameterStore.ts`** — invalidate cache after a mutation resolves
  `AUTO_APPLIED`, and after any approval.
- **`src/config/menuConfig.tsx`** — verify the Parameter menu is gated by `parameter:view`.

---

## Files

**Create — `ulos-orchestration-service`**
- `src/main/resources/db/migration/V4__create_parameter_tables.sql`
- `src/main/resources/db/migration/V5__seed_parameters.sql`
- `domain/parameter/` — 4 entities (`ParameterEntity`, `ParameterItemEntity`,
  `ParameterChangeRequestEntity`, `ParameterSettingEntity`), 3 enums, 4 repositories
- `service/` — `ParameterQueryService` + `Impl`, `ParameterChangeRequestService` + `Impl`,
  `ParameterSettingService` + `Impl`
- `adapter/inbound/ParameterController.java` + `adapter/inbound/dto/` records
- `config/CacheConfig.java`

**Modify — `ulos-orchestration-service`**
- `pom.xml` (redis + cache starters)
- `src/main/resources/application.yml`, `application-dev.yml` (redis config)

**Create — `ulos-iam-service`**
- `src/main/resources/db/migration/V5__add_parameter_permissions.sql`

**Modify — `ulos-ui`**
- `src/types/parameter.ts`, `src/api/parameterApi.ts`, `src/store/useParameterStore.ts`,
  `src/pages/ParameterListPage.tsx`, `src/pages/ParameterDetailPage.tsx`,
  `src/config/menuConfig.tsx`,
  `src/components/parameter/*` (modals + new `ChangeRequestPanel` + `MakerCheckerSettings`)

---

## Verification

**Backend**
1. `docker-compose up -d` (Postgres, Kafka, Redis, Keycloak).
2. `mvn -pl ulos-orchestration-service spring-boot:run` — Flyway V4/V5 apply cleanly.
3. `mvn test` — `ArchitectureComplianceTest` / `ArchUnit` pass (entities extend
   `BaseEntity`, DTOs are records, service = interface + Impl).
4. Manual (via gateway `:8000`, Keycloak JWT):
   - Maker (`parameter:manage`) `POST /api/v1/parameters` → **202**, status `PENDING_APPROVAL`.
   - `GET /api/v1/parameters` → new parameter **not** visible (still staged).
   - Same maker `POST .../approve` → **error** (4-eyes block).
   - Checker (`parameter:approve`) `POST .../approve` → **200**; parameter now in `GET` list.
   - `redis-cli KEYS 'ulos:parameters*'` → cache populated; re-evicted after next approve.
   - `POST .../reject` with comment → status `REJECTED`, live tables unchanged.
   - `PUT /api/v1/parameters/settings {makerCheckerEnabled:false}` → next maker mutation
     returns **200** status `AUTO_APPLIED` and is live immediately (gate OFF).
   - Re-enable global; `PUT .../{code}/approval-policy {requiresApproval:false}` → a
     mutation on *that* parameter returns `AUTO_APPLIED`, while a mutation on a still-
     governed parameter returns `PENDING_APPROVAL`.

**Frontend**
5. `cd ulos-ui && npm install && npm run dev` (`:3002`).
   - Login as maker → create parameter/item → toast *"Diajukan untuk persetujuan"*.
   - Login as checker → "Pending Approval" tab → approve → parameter appears in list;
     loan-wizard LOV dropdowns still populate (seeded data).
   - Checker toggles the global maker-checker switch off → a maker create now toasts
     *"Perubahan disimpan"* and appears immediately.
6. `npm run build && npm run lint && npm test` all pass.
