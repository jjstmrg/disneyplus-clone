# Integrasi Surrounding + Simulator/Mock

## Context

ULOS perlu integrasi ke 5 sistem "surrounding" (sistem sekitar core bank) untuk proses kredit:
ICLListing, BWCCS, IVAS, SLIK, ICRES. Surrounding belum siap, jadi dibuat **simulator/mock** dulu
yang meniru kontrak (JSON + WSDL/XML + FTP + callback). Tujuan: kode integrasi final, nanti tinggal
**ganti base-url** dari simulator ke surrounding asli tanpa ubah logic.

Hasil eksplorasi: `ulos-integration-service` saat ini hexagonal + ACL + OpenFeign + Resilience4j,
**JSON-only**, belum ada SOAP/WSDL, FTP, atau callback. Pola mock existing = inline controller
(`controller/mock/CoreBankingMockController.java`). Konvensi (AGENTS.md): semua call eksternal lewat
`acl/`, DTO = `record`, service = interface+Impl, response `ApiResponse<T>`, entity extend `BaseEntity`,
migrasi Flyway `V{n}__*.sql`, `ArchitectureComplianceTest` harus tetap hijau.

5 service & transport (sudah dikonfirmasi):

| Service | Transport | Sync/Async | Input | Output |
|---|---|---|---|---|
| **ICLListing** | SOAP/WSDL (XML) | sync | `cifNo` | daftar loan existing di core |
| **BWCCS** | JSON | sync | kategori: idno / fullname / dob / npwp / alamat | credit scoring bank-wide per kategori |
| **IVAS** | JSON + callback | async | aset/collateral | hasil investigasi via callback |
| **SLIK** | JSON + callback + FTP | async | subject (idno) | callback notif → hasil JSON diambil dari FTP |
| **ICRES** | SOAP/WSDL (XML) | sync | company id | scoring financial + rating perusahaan |

Keputusan desain: (1) simulator = **modul standalone** `ulos-surrounding-simulator` port 8089;
(2) ICL & ICRES **contract-first SOAP** (XSD→WSDL→JAXB via spring-ws); (3) FTP = **container nyata** +
`commons-net`; (4) hasil async **disimpan di schema `integration` + diexpose via REST GET** (belum publish Kafka downstream).

---

## Bagian A — Modul baru `ulos-surrounding-simulator` (port 8089)

Meniru surrounding. Package `com.ulos.surrounding.simulator`.

**Registrasi modul:**
- Root `pom.xml`: tambah `<module>ulos-surrounding-simulator</module>`.
- `ulos-surrounding-simulator/pom.xml`: parent `ulos-parent`; deps: `spring-boot-starter-web`,
  `spring-boot-starter-web-services` (spring-ws), `commons-net` (FTP upload), `spring-boot-starter-actuator`,
  Lombok. Plugin `jaxb2-maven-plugin` untuk generate JAXB dari XSD.
- `Dockerfile`: ikut pola multi-stage `ulos-integration-service/Dockerfile` (strip module via sed,
  build `-pl ulos-surrounding-simulator -am`, base `eclipse-temurin:21-jre-alpine`, non-root, EXPOSE 8089, healthcheck actuator).

**SOAP (ICL & ICRES) — contract-first:**
- `src/main/resources/xsd/icl-listing.xsd`, `src/main/resources/xsd/icres.xsd` — schema request/response
  (ICL: `IclListingRequest{cifNo}` → `IclListingResponse{loans[]}`; ICRES: `IcresRequest{companyId}` →
  `IcresResponse{rating, financialScore, ...}`).
- `config/WebServiceConfig.java`: `MessageDispatcherServlet` + `DefaultWsdl11Definition` per XSD →
  WSDL auto ke `/ws/icl-listing.wsdl` & `/ws/icres.wsdl`. `XsdSchema` bean per file.
- `endpoint/IclListingEndpoint.java`, `endpoint/IcresEndpoint.java`: `@Endpoint` + `@PayloadRoot`,
  return data mock (loan list / company rating).

**JSON (BWCCS / IVAS / SLIK):**
- `controller/BwccsSimController.java`: `POST /sim/bwccs/inquiry` body `{category, value}` →
  hasil scoring dikelompokkan per kategori. Data mock in-memory (pola `CoreBankingMockController`).
- `controller/IvasSimController.java`: `POST /sim/ivas/request` → ack `{requestId, status:ACCEPTED}`,
  lalu **async** (`@Async`+delay atau `@Scheduled` queue) `POST {callbackUrl}` dgn hasil investigasi.
- `controller/SlikSimController.java`: `POST /sim/slik/request` → ack `{requestId}`, lalu async:
  tulis hasil JSON ke **FTP** (`SimFtpUploader` pakai commons-net, path `/slik/{requestId}.json`),
  lalu `POST {callbackUrl}` notif `{requestId, ftpPath, status:READY}`.
- `service/SimFtpUploader.java`: connect FTP (host/port/user/pass dari config) + `storeFile`.
- `application.yml`: `server.port: 8089`; `simulator.callback.delay`, `simulator.ftp.{host,port,user,pass,base-dir}`,
  default callback target `http://localhost:8083`.

---

## Bagian B — `ulos-integration-service` (sisi consumer ACL)

Tambah dependency di `ulos-integration-service/pom.xml`:
`spring-boot-starter-web-services` (WebServiceTemplate), `commons-net` (FTP download),
plugin `jaxb2-maven-plugin` (generate JAXB dari XSD yang dicopy ke `src/main/resources/xsd/` — kontrak sama dgn simulator).

**Config baru (`config/`):**
- `SoapClientConfig.java`: `Jaxb2Marshaller` (contextPath ke package JAXB hasil generate) +
  `WebServiceTemplate` bean (default-uri dari config). Bisa 1 template parametrik atau per-service.
- `FtpClientConfig.java` / `FtpResultClient.java`: ambil file JSON dari FTP via commons-net
  (`retrieveFileStream`), return byte[]/String.

**ACL adapters (`acl/`) — semua call eksternal lewat sini (rule AGENTS.md):**
- `IclListingAdapter` (SOAP, sync): `marshalSendAndReceive` → map `IclListingResponse` ke DTO domain.
- `BwccsAdapter` (Feign JSON, sync): kelompokkan hasil per kategori.
- `IcresAdapter` (SOAP, sync): map rating + financial score.
- `IvasAdapter` (async): simpan `IvasInvestigation` status=REQUESTED, panggil simulator dgn `callbackUrl`,
  return `requestId`.
- `SlikAdapter` (async): simpan `SlikRequest` status=REQUESTED, panggil simulator dgn `callbackUrl`, return `requestId`.
- Semua: `@CircuitBreaker`+`@Retry`+`@AuditLog`+`@Timed` (pola `CoreBankingIntegrationAdapter`).

**Feign clients (`adapter/`):** `BwccsClient`, `IvasClient`, `SlikClient` — base-url dari config.
(ICL & ICRES pakai `WebServiceTemplate`, bukan Feign.)

**Inbound REST (`adapter/inbound/`):** controller baru `SurroundingController` (atau perluas `IntegrationController`):
- `POST /api/v1/integrations/icl/listing` (cifNo) → sync
- `POST /api/v1/integrations/bwccs/inquiry` (kategori) → sync
- `POST /api/v1/integrations/icres/scoring` (companyId) → sync
- `POST /api/v1/integrations/ivas/request` → async, return requestId
- `POST /api/v1/integrations/ivas/callback` ← simulator (update hasil)
- `GET  /api/v1/integrations/ivas/{requestId}` → status+hasil
- `POST /api/v1/integrations/slik/request` → async, return requestId
- `POST /api/v1/integrations/slik/callback` ← simulator (notif FTP-ready → integration download FTP, parse, simpan)
- `GET  /api/v1/integrations/slik/{requestId}` → status+hasil
- Controller tetap **tipis**, delegasi ke adapter/service. Response `ApiResponse<T>`.

**Persistence:**
- Entity `entity/IvasInvestigationEntity`, `entity/SlikRequestEntity` extend `BaseEntity`.
  Kolom: requestId (unique), correlationId, **referenceType (APPLICATION/PORTFOLIO) + referenceId**,
  input ringkas, status (REQUESTED/COMPLETED/FAILED), resultJson (text), ftpPath (SLIK), requestedAt, completedAt.
- Repository `IvasInvestigationRepository`, `SlikRequestRepository` (Spring Data, `findByRequestId`).
- Flyway `src/main/resources/db/migration/V4__add_surrounding_async_tables.sql` (schema `integration`):
  `tb_ivas_investigation`, `tb_slik_request` + kolom audit `BaseEntity`.

**DTO:** request/response JSON = `record` (konvensi AGENTS.md). JAXB SOAP class = hasil generate (bukan record).

**`application.yml`:** tambah blok `ulos.integration.surrounding.{icl,bwccs,ivas,slik,icres}.base-url`,
`...icl.wsdl`/`icres.wsdl` (atau default-uri SOAP), `...callback.base-url` (URL service ini yg dipanggil simulator),
`...ftp.{host,port,user,pass,base-dir}`. Tambah Resilience4j instance: `icl`, `bwccs`, `ivas`, `slik`, `icres`
(circuitbreaker+retry+timelimiter, pola existing).

**Security:** endpoint `*/callback` dipanggil simulator (internal) — di `SecurityConfig` set `permitAll`
untuk path callback (atau validasi shared-secret header). Dicatat sebagai internal-only.

---

## Bagian D — Admin: menu Integration History per Apps/Portfolio

Tujuan: admin bisa lihat **tabel history call integrasi** (ke 5 surrounding) yang dikelompokkan
per **application / portfolio yang dicek**.

**Masalah yang harus diatasi dulu:**
- Audit existing (`integration_audit_log` + `IntegrationAuditInterceptor`) cuma punya `correlationId`,
  dan FE (`api/client.ts`) generate `X-Correlation-ID` **random per-request** → tidak stabil per app/portfolio.
  Maka history harus di-key pakai **referenceType + referenceId** (APPLICATION/PORTFOLIO + id), bukan correlationId.
- Aspect audit cuma jalan untuk `@FeignClient` (`@within(feignClient)`). Call SOAP (ICL/ICRES via
  WebServiceTemplate) **tidak tercatat** → harus ditulis manual.

**Backend (`ulos-integration-service`):**
- Flyway `V5__add_reference_to_audit_log.sql`: tambah kolom nullable `reference_type`, `reference_id`
  ke `integration_audit_log` (expand-only, sesuai ADR-0006). (Kolom referensi di tabel async IVAS/SLIK
  ikut di `V4`.)
- `context/ReferenceContext.java`: ThreadLocal (mirror `CorrelationContext` dari common).
- `config/ReferenceContextFilter.java` (`OncePerRequestFilter`): baca header `X-Reference-Type` /
  `X-Reference-Id`, set context, clear di finally. Endpoint surrounding inbound mewajibkan/menerima
  referensi ini (header dari caller; FE kirim saat memicu pengecekan dari layar app/portfolio).
- `IntegrationAuditInterceptor`: isi `referenceType`/`referenceId` dari `ReferenceContext`.
- `service/IntegrationAuditWriter.java`: helper tulis audit log manual — dipakai `IclListingAdapter` &
  `IcresAdapter` (SOAP) supaya history lengkap incl reference + payload XML + status + durasi.
- `IntegrationAuditLogRepository`: tambah query paged `findByReferenceTypeAndReferenceId(...)` +
  filter opsional vendor/status (derived query atau `@Query`).
- Endpoint admin (`IntegrationHistoryController` atau perluas `IntegrationController`):
  `GET /api/v1/integrations/history?referenceType=&referenceId=&vendor=&status=&page=&size=`
  → `ApiResponse<Page<...>>` (list pakai DTO ringkas `record` tanpa payload besar);
  `GET /api/v1/integrations/history/{id}` → detail incl request/response payload.
  Guard authority admin (`@PreAuthorize` / `SecurityConfig`).

**Frontend (`ulos-ui`):**
- `api/integrationApi.ts`: `getIntegrationHistory(params)` + `getIntegrationHistoryDetail(id)` + types;
  support mock via `useMockConfigStore` (pola `cifApi.ts`).
- `pages/IntegrationHistoryPage.tsx`: filter (Reference Type select APPLICATION/PORTFOLIO + Reference Id +
  vendor + status), tabel paged (vendor, endpoint, status, httpStatus, durationMs, createdDate),
  klik baris → dialog detail (request/response payload, updatedFields).
- `App.tsx`: route `/admin/integration-history` dibungkus `ProtectedRoute requiredPermission="integration:view"`
  (lazy import, pola existing).
- `config/menuConfig.tsx`: item baru di section admin → `path:'/admin/integration-history'`,
  `labelKey:'integration_history'`, icon `History`/`Activity` (lucide), `permission:'integration:view'`.
- `locales/translations.ts`: tambah key `integration_history` + label filter (id & en).
- Permission/role: tambah `integration:view` di `infra/keycloak/realm-export.json` (atau config security)
  dan map ke role admin.
- Opsional: tab "Integration History" di `ApplicationDetailPage` / `PortfolioDetailPage` yang prefilled
  `referenceId` halaman tsb (reuse `integrationApi`) — tandai opsional.

---

## Bagian C — Infra

`docker-compose.yml`:
- **ftp-surrounding** (mis. `delfer/alpine-ftp-server`): env `FTP_USER`/`FTP_PASS`, port 21 + passive range, volume data.
- **ulos-surrounding-simulator**: build Dockerfile, port 8089, env FTP creds + `SIMULATOR_CALLBACK_BASEURL=http://api-gateway:8000` atau `http://ulos-integration:8083`, `SPRING_PROFILES_ACTIVE=docker`.
- **ulos-integration** (update env): `SURROUNDING_*_URL` → `http://ulos-surrounding-simulator:8089/...`,
  FTP creds, `INTEGRATION_CALLBACK_BASEURL`.

`ulos-parent/pom.xml`: `dependencyManagement` versi `commons-net` + `pluginManagement` `jaxb2-maven-plugin`.

Gateway: route `/api/v1/integrations/**` sudah ada → endpoint baru ikut otomatis. Route simulator/SOAP **tidak**
diexpose publik (internal); opsional tambah route `/ws/**`→simulator hanya untuk uji manual WSDL.

---

## Parameter / asumsi yang dipakai
- Package simulator: `com.ulos.surrounding.simulator`. Vendor code: `ICL`, `BWCCS`, `IVAS`, `SLIK`, `ICRES`.
- Layout integration-service ikut existing (`adapter/`, `acl/`, `entity/`, `repository/`, `config/`) bukan `adapter/outbound`+`domain` ideal AGENTS.md — konsisten dgn modul & `ArchitectureComplianceTest` saat ini.
- Frontend (ulos-ui) **di luar scope** kecuali diminta.
- Callback async pakai polling GET (belum Kafka ke orchestration/bpm).

---

## Verifikasi (end-to-end)

1. **Build**: `mvn -q -pl ulos-surrounding-simulator,ulos-integration-service -am clean package`
   → JAXB ter-generate, semua modul compile, `ArchitectureComplianceTest` hijau.
2. **Up**: `docker compose up -d ftp-surrounding ulos-surrounding-simulator ulos-integration` (+ postgres).
3. **WSDL**: `GET http://localhost:8089/ws/icl-listing.wsdl` & `/ws/icres.wsdl` → XML valid.
4. **ICL (SOAP)**: POST `/api/v1/integrations/icl/listing` `{cifNo}` → daftar loan.
5. **BWCCS (JSON)**: POST `/api/v1/integrations/bwccs/inquiry` tiap kategori (idno/fullname/dob/npwp/alamat) → scoring per kategori.
6. **ICRES (SOAP)**: POST `/api/v1/integrations/icres/scoring` `{companyId}` → rating + financial score.
7. **IVAS (async)**: POST `/ivas/request` → `requestId`; tunggu callback; `GET /ivas/{requestId}` → status COMPLETED + hasil.
8. **SLIK (async+FTP)**: POST `/slik/request` → `requestId`; simulator tulis JSON ke FTP + callback;
   cek file ada di FTP; `GET /slik/{requestId}` → hasil ter-parse dari FTP, status COMPLETED.
9. **Resilience**: matikan simulator → adapter sync fallback rapi (bukan silent success), CB open sesuai config.
10. **Swap test**: ganti `SURROUNDING_*_URL` → host lain tanpa ubah kode (bukti "tinggal menyesuaikan").
11. **Admin history**: kirim beberapa call (ICL/BWCCS/IVAS/SLIK/ICRES) dengan header `X-Reference-Type`/
    `X-Reference-Id` untuk satu application & satu portfolio; `GET /api/v1/integrations/history?...` →
    semua call tercatat (termasuk SOAP) dengan reference benar.
12. **UI menu**: login admin → menu "Integration History" muncul; filter by application/portfolio →
    tabel tampil; klik baris → detail payload. Cek juga mode `VITE_USE_MOCK=true` jalan.
