# Plan: Fix Review Findings 1-3 (Pre-Push)

## Context

Code review surfaced 3 blocker categories on uncommitted diff. Must fix **before** any push to remote — finding 1 contains real-looking secrets, finding 2 silently breaks RBAC endpoint, finding 3 will block boot if not reconciled.

User decisions confirmed:
- Schema `los` abandoned — fresh start with schema `orchestration` + `flowable` + `audit` (per new V1).
- Solo dev preparing repo for squad handoff. Fix posture must be safe-by-default for squads.

Critical files identified:
- `.env.example` — secret leak
- `temp_key.txt`, `Archive.zip`, `table_list.txt`, `*.bak` — untracked but in repo root
- `.gitignore` — incomplete
- `ulos-orchestration-service/src/main/java/com/ulos/orchestration/config/KeycloakJwtAuthenticationConverter.java` — prefix bug
- `ulos-orchestration-service/src/main/java/com/ulos/orchestration/adapter/inbound/ApprovalQueueController.java` — uses `hasAuthority('approval_queue:view')` that won't match
- `infra/keycloak/realm-export.json` — no `permissions` claim mapper
- `ulos-orchestration-service/src/main/resources/application.yml` — schema/ddl/flowable config inconsistent
- `ulos-orchestration-service/src/main/resources/db/migration/V1__init_orchestration_schema.sql` + `V2__add_bpmn_deployment_table.sql` — new fresh-start migrations
- `docker-compose.yml` — postgres-orchestration init flow

---

## Finding 1 — Secret & Repo Hygiene

### 1.1 Rotate compromised Keycloak client secret
- Generate new secret in Keycloak admin (or `realm-export.json` `clientSecret` field).
- Update local `.env` (NOT `.env.example`).
- Treat existing `CZ7VLkhGPTSUjOokcTBVPyTCIBmBlhdp` as compromised.

### 1.2 Sanitize `.env.example`
Replace lines 14, 18-19:
```
KEYCLOAK_CLIENT_SECRET=replace_with_value_from_keycloak_admin
ULOS_AES_KEY=replace_with_openssl_rand_base64_32
```
Remove the comment that teaches predictable key (`MTIzNDU2Nzg5MDEy...`).
Add comment: `# Generate: openssl rand -base64 32`.

### 1.3 Delete untracked artifacts from disk
- `Archive.zip` (300MB) — move outside repo or delete
- `temp_key.txt` (32-char hex key) — delete, key compromised
- `table_list.txt` — delete (schema dump leftover)
- `ulos-ui/src/pages/BpmnDeploymentPage.tsx.bak` — delete (git history is the backup)

### 1.4 Harden `.gitignore`
Append:
```
# Binary archives
*.zip
*.tar.gz

# Editor backup files
*.bak
*.swp
*~

# Temp / scratch
temp_*.txt
scratch/
secrets/
*.pem
*.key
credentials.json
```

### 1.5 Pre-commit secret scan (deferred but documented)
Document in CLAUDE.md: install `gitleaks` pre-commit hook. Not implemented this PR.

---

## Finding 2 — Keycloak Auth Converter Fix

### 2.1 Root cause
`KeycloakJwtAuthenticationConverter.java:73` prefixes every authority with `ROLE_`. `ApprovalQueueController.java:17` uses `hasAuthority('approval_queue:view')` (exact match, no `ROLE_`). Authority becomes `ROLE_approval_queue:view` → never matches → 403.

Also `extractAuthorities` iterates ALL clients in `resource_access` — leaks `account.manage-account` etc. into authorities.

### 2.2 Fix strategy — dual-source claim
Two claim sources, two destinations:

| Source                                    | Prefix    | Used by                              |
|-------------------------------------------|-----------|--------------------------------------|
| `realm_access.roles`                      | `ROLE_`   | `hasAnyRole('LOAN_OFFICER', ...)`    |
| `permissions` (custom claim, flat array)  | none      | `hasAuthority('approval_queue:view')`|
| `resource_access.{ULOS_CLIENT_ID}.roles`  | none      | Same as `permissions` (fallback)     |

Rules:
- Realm roles → `ROLE_` prefix (preserve existing `hasAnyRole` controllers)
- Permission claim → no prefix (raw `resource:action` strings)
- Filter `resource_access` to ULOS client only (env var `ULOS_KEYCLOAK_CLIENT_ID`, default `ulos-app`) — skip `account`, `realm-management`

### 2.3 Code change — `KeycloakJwtAuthenticationConverter.java`
```java
@Value("${ulos.security.keycloak.client-id:ulos-app}")
private String ulosClientId;

private Collection<GrantedAuthority> extractAuthorities(Jwt jwt) {
    List<GrantedAuthority> result = new ArrayList<>();

    // Realm roles → ROLE_ prefix
    Map<String, Object> realmAccess = jwt.getClaimAsMap(REALM_ACCESS);
    if (realmAccess != null && realmAccess.get(ROLES) instanceof List<?> realmRoles) {
        realmRoles.stream()
            .filter(String.class::isInstance)
            .map(String.class::cast)
            .map(r -> ROLE_PREFIX + r)
            .map(SimpleGrantedAuthority::new)
            .forEach(result::add);
    }

    // Custom flat permissions claim → no prefix
    List<String> permissions = jwt.getClaimAsStringList("permissions");
    if (permissions != null) {
        permissions.stream()
            .map(SimpleGrantedAuthority::new)
            .forEach(result::add);
    }

    // ULOS client roles only → no prefix
    Map<String, Object> resourceAccess = jwt.getClaimAsMap(RESOURCE_ACCESS);
    if (resourceAccess != null && resourceAccess.get(ulosClientId) instanceof Map<?, ?> clientAccess) {
        Object clientRoles = clientAccess.get(ROLES);
        if (clientRoles instanceof List<?> cr) {
            cr.stream()
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .map(SimpleGrantedAuthority::new)
                .forEach(result::add);
        }
    }

    return result.stream().distinct().collect(Collectors.toList());
}
```
Also: drop `implements Converter`, extend nothing. Since `@Bean` returns `KeycloakJwtAuthenticationConverter` and is used at `oauth2.jwt(jwt -> jwt.jwtAuthenticationConverter(...))`, must implement `Converter<Jwt, AbstractAuthenticationToken>` (already does). Keep that.

### 2.4 Keycloak realm change — add permissions claim
Edit `infra/keycloak/realm-export.json`:
- Add **Protocol Mapper** to `ulos-app` client: type `oidc-usermodel-attribute-mapper` or `oidc-hardcoded-claim-mapper` mapping role composite → `permissions` claim (Token + ID Token, multivalued).
- Easier alternative: **composite roles**. Define realm roles `application:read`, `approval_queue:view`, `bpmn:deploy`, etc. Assign as composite to structural role (e.g., `CHECKER` composite of `approval_queue:view`, `application:read`). Then add User Realm Role mapper → `permissions` claim multivalued.

Document the mapper config (JSON snippet) inline in `infra/keycloak/README.md` for squad onboarding.

### 2.5 application.yml — add property
```yaml
ulos:
  security:
    keycloak:
      client-id: ${KEYCLOAK_CLIENT_ID:ulos-app}
```

### 2.6 Verify `ApprovalQueueController` end-to-end
- Login with user that has `permissions: ["approval_queue:view"]` claim
- `GET /api/loans/v1/approvals/queue` → 200
- Login without claim → 403

---

## Finding 3 — Schema / Migration Reconciliation (Fresh Start)

User confirmed: schema `los` abandoned. Path = **destructive reset** of dev DB, then Flyway provisions from V1.

### 3.1 Wipe existing orchestration DB

⚠ **Destructive — local/dev only**. Run by user, not automated in code.

```bash
docker compose stop orchestration-service
docker compose exec postgres-orchestration psql -U postgres -c "DROP DATABASE ulos_orchestration;"
docker compose exec postgres-orchestration psql -U postgres -c "CREATE DATABASE ulos_orchestration OWNER ulos_orch_user;"
docker compose up -d orchestration-service
```

### 3.2 Add postgres init script (one-time bootstrap)
`infra/postgres/orchestration/01-init.sql`:
```sql
-- Run at container first-boot (mounted to /docker-entrypoint-initdb.d/)
CREATE USER ulos_orch_user WITH PASSWORD :'orch_password';
CREATE DATABASE ulos_orchestration OWNER ulos_orch_user;

\c ulos_orchestration

CREATE SCHEMA IF NOT EXISTS orchestration AUTHORIZATION ulos_orch_user;
CREATE SCHEMA IF NOT EXISTS flowable     AUTHORIZATION ulos_orch_user;
CREATE SCHEMA IF NOT EXISTS audit        AUTHORIZATION ulos_orch_user;

GRANT ALL ON SCHEMA orchestration TO ulos_orch_user;
GRANT ALL ON SCHEMA flowable     TO ulos_orch_user;
GRANT ALL ON SCHEMA audit        TO ulos_orch_user;
```

Mount in `docker-compose.yml` postgres-orchestration service:
```yaml
volumes:
  - ./infra/postgres/orchestration:/docker-entrypoint-initdb.d:ro
```

Note: Flyway V1 also has `CREATE SCHEMA IF NOT EXISTS ...`. Redundant but idempotent — keep both for safety (Flyway-only setup also works for CI).

### 3.3 Fix `application.yml` inconsistencies

Lines 33-44 in `ulos-orchestration-service/src/main/resources/application.yml`:

Replace block:
```yaml
jpa:
  open-in-view: false
  show-sql: false
  hibernate:
    ddl-auto: validate
  properties:
    hibernate:
      dialect: org.hibernate.dialect.PostgreSQLDialect
      default_schema: orchestration
      format_sql: true
```

Removed:
- `hbm2ddl.auto: none` (duplicate of `ddl-auto`)
- `javax.persistence.schema-generation.database.action: none` (wrong namespace for Spring Boot 3 — should be `jakarta.persistence.*`, but unnecessary anyway)
- `#start ====` / `#end ====` comment clutter

Change `ddl-auto: none` → `ddl-auto: validate`. Rationale: Flyway owns DDL, JPA verifies entities match. `none` skips verification = silent runtime errors when entity drifts from schema.

Lines 88-91 — Flowable:
```yaml
flowable:
  database-schema: flowable
  database-schema-update: true   # Flowable self-creates ACT_* on first boot
```

Keep `database-schema-update: true` **for now** (V1 doesn't create ACT_* tables — Flowable engine bootstraps them). After engine separation milestone (future), tighten to `false` + Flyway-managed.

Add comment in file explaining the asymmetry vs JPA `ddl-auto: validate`.

### 3.4 Verify entity `@Table(schema = ...)` annotations
Sample check (Explore confirmed entities exist for):
- `LoanApplicationEntity` → must `@Table(name = "tb_loan_application", schema = "orchestration")` or rely on `default_schema`
- `BpmnDeploymentEntity` → same
- `AuditLogEntity` (common-jpa-audit) → `schema = "audit"`

Default schema `orchestration` covers orchestration entities; audit entity needs explicit `schema = "audit"`. Verify before boot.

### 3.5 Delete stale Flowable migration
`V99__migrate_flowable_to_schema.sql` already deleted in working tree (per `git status`). Confirm — fresh start renders it moot.

---

## Verification

### Finding 1
- `git ls-files` does not list `Archive.zip`, `temp_key.txt`, `table_list.txt`, `*.bak`
- `grep -E "CZ7VL|MTIzND" .env.example` returns nothing
- `git check-ignore Archive.zip temp_key.txt foo.bak` returns all paths
- Manual: `gitleaks detect --source .` clean (if installed)

### Finding 2
- Boot orchestration with new converter
- `curl -H "Authorization: Bearer <token-without-perm>" http://localhost:8082/api/loans/v1/approvals/queue` → 403
- `curl -H "Authorization: Bearer <token-with-approval_queue:view>" ...` → 200
- Decode JWT, confirm `permissions` claim present
- All existing `hasAnyRole(...)` endpoints (16 controllers) still return 200 for proper user
- `account.manage-account` no longer in `getAuthorities()` output (log SecurityContext)

### Finding 3
- `docker compose down -v` on postgres-orchestration volume
- `docker compose up postgres-orchestration` → init script runs, schemas exist
- `docker compose up orchestration-service` → Flyway V1, V2 apply, JPA `validate` passes, app boots
- `psql ulos_orchestration -c "\dn"` shows `orchestration`, `flowable`, `audit`
- `psql ulos_orchestration -c "SELECT version FROM orchestration.flyway_schema_history"` shows 1, 2
- Flowable engine boots and creates `flowable.ACT_*` tables (check `\dt flowable.*`)
- Run smoke test: create loan application → confirm row in `orchestration.tb_loan_application`

---

## Execution Order (sequence matters)

1. **Finding 1** first — sanitize secrets before any other commit (avoid accidental push of leaked state during finding 2/3 work)
2. **Finding 3** second — fresh DB needed before testing finding 2 RBAC end-to-end
3. **Finding 2** third — test against clean DB with new realm config

Estimated solo time: **1 day** (finding 1: 1h, finding 3: 3h incl. testing, finding 2: 3h incl. realm mapper + e2e test, buffer: 1h).

---

## Out of Scope (defer)

- Permission registry (TS constants + Java enum) — separate task
- 15-page permission inventory — separate task
- Composite role design in Keycloak — discuss with security squad once formed
- ArchitectureComplianceTest tightening — separate task
- gitleaks/pre-commit infra — separate task
- Migration to External Task pattern + engine split — separate epic
