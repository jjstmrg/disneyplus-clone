# Plan — Fix Flowable process-key mismatch (single shared process)

## Context

Testing from Postman produces no movement in the Flowable tables. Root cause: the
BPMN's `<process id>` is `Process_1yy5dvm` (an auto-generated modeler id), but
`ProcessStartService` starts the process by key `loan-origination-process`
(`FlowableProperties.processKey` default — orchestration sends `processKey=null`,
so bpm-service falls back to that default). Flowable registers a process definition
under the XML `<process id>`, so `startProcessInstanceByKey("loan-origination-process", …)`
throws `FlowableObjectNotFoundException` — no process instance is created, the
`ACT_RU_*` tables stay empty.

User decision: get one product working first with a single shared process;
per-product keys come later.

## Fix — one file

Edit `ulos-bpm-service/src/main/resources/bpmn/diagram_1-v3_2.bpmn` (the BPMN
currently on disk; the old `diagram_1-v3 1.bpmn` was already removed):

- line 4: `processRef="Process_1yy5dvm"` → `processRef="loan-origination-process"`
- line 6: `<process id="Process_1yy5dvm" name="Process_1yy5dvm" …>` →
  `id="loan-origination-process" name="Loan Origination Process"`
- line 12 `<laneSet id="laneSet_Process_1yy5dvm">` — leave as-is (internal lane-set
  id, no link to the process-definition key).

Result: the Flowable process-definition key becomes `loan-origination-process` —
exactly the key `ProcessStartService` starts.

## Required runtime steps (user, after the edit)

The BPMN under `resources/bpmn/` is **not** classpath-autodeployed.
`BpmnDeploymentService.deployBpmn(productCode, version, bpmnXml, …)` deploys an
uploaded XML; the Flowable definition key = the XML `<process id>`.

1. Rebuild + restart **bpm-service** and **orchestration-service** — picks up the
   earlier Kafka deserialization fix, required for the process-start event to be
   consumed at all.
2. Deploy the edited BPMN via `BpmnDeploymentController` / the BpmnDeploymentPage
   UI — choose a `productCode` (e.g. KPR) and version. Flowable registers
   `loan-origination-process`.
3. Activate the deployed version (`BpmnDeploymentService.activateVersion`) —
   `deployBpmn` saves it `isActive=false`; activation is the ULOS bookkeeping step.

## Verification

- Submit a loan via Postman → orchestration → outbox → Kafka → bpm-service.
- bpm-service log: `Process started: applicationId=<uuid> processInstanceId=<id>
  processKey=loan-origination-process`.
- DB: `SELECT key_ FROM flowable.act_re_procdef;` → row `loan-origination-process`;
  `SELECT count(*) FROM flowable.act_ru_execution;` → > 0.
- orchestration log: `Updated processInstanceId application=<uuid> → …`.

## Deferred (not in this change)

- **Per-product keys (Option B)** — when ready: each product BPMN gets
  `<process id>=loan-origination-{product}`, `ProcessStartService` derives the key
  from `productType` reusing `BpmnDeploymentService.resolveProcessKey(...)` logic.
- Git housekeeping: `diagram_1-v3 1.bpmn` shows deleted, `diagram_1-v3_2.bpmn`
  untracked — the file swap; commit them together when ready.
