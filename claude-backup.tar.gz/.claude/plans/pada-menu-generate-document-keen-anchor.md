# Edit-Before-PDF flow untuk Generate Document (format Word)

## Context

Menu Generate Document (`DocumentGeneratorTab`) sekarang: pilih template + format (PDF/DOCX) → klik generate → backend render Mustache → langsung kompilasi ke biner (PDF/DOCX) → upload S3 → simpan. Tidak ada kesempatan user mengoreksi nilai hasil populate sistem.

Permintaan user: saat format **Word** dipilih, jangan langsung jadikan file. Buka **tab baru** berisi hasil generate yang **bisa diedit** (edit value hasil populate sistem). Setelah user puas, klik convert → **output final selalu PDF**.

Keputusan user:
- Output final = **selalu PDF**.
- Editor = **contentEditable inline** (WYSIWYG ringan, tanpa dependency baru).
- Path PDF (pilih PDF langsung) tetap seperti sekarang — tanpa edit.

Alur baru: pilih Word → tab baru → `render-draft` (HTML hasil Mustache, belum dikompilasi) → user edit inline → "Convert to PDF" → `generate-from-html` → PDF tersimpan sebagai dokumen GENERATED.

## Backend — `ulos-document-service`

### `DocumentGeneratorService.java`
Refactor `generateDocument` (line 62-224) jadi blok reusable, tanpa ubah perilaku lama:
- Ekstrak langkah 1-3 + Mustache render (line 67-179) → `private RenderedDraft buildRenderedDraft(UUID applicationId, String templateCode)` mengembalikan record `(DocumentTemplateEntity template, String xhtml, UUID portfolioId)`. Termasuk ensure-XHTML-root wrap (line 176-179).
- Ekstrak langkah 4-6 (line 181-223) → `private GeneratedDocumentEntity compileAndPersist(DocumentTemplateEntity template, String xhtml, String format, UUID applicationId, UUID portfolioId)` (compile PDF/DOCX via `compileToPdf`/`compileToDocx` yang sudah ada, upload S3, simpan entity).
- `generateDocument` = `buildRenderedDraft` + `compileAndPersist` (output identik dgn sekarang).

Method publik baru:
- `public RenderedDraft renderDraft(UUID applicationId, String templateCode)` → panggil `buildRenderedDraft`, kembalikan xhtml + templateName. Read-only (tidak simpan apa-apa).
- `public GeneratedDocumentEntity generateFromHtml(UUID applicationId, String templateCode, String editedHtml)` → ambil template (cek aktif), `fetchPortfolioId(applicationId)`, ensure-XHTML-root wrap pada `editedHtml`, lalu `compileAndPersist(..., "PDF", ...)`. portfolioId di-extract pakai logika sama spt line 200-209 (ekstrak jadi helper `fetchPortfolioId`).

### `DocumentGeneratorController.java`
Dua endpoint baru (pola sama dgn `/generate` line 42-49):
- `POST /api/loans/v1/documents/render-draft` — body `RenderDraftRequest(UUID applicationId, String templateCode)` → `ApiResponse<RenderDraftResponse(String html, String templateName, String templateCode)>`.
- `POST /api/loans/v1/documents/generate-from-html` — body `GenerateFromHtmlRequest(UUID applicationId, String templateCode, String html)` → `ApiResponse<GeneratedDocumentEntity>` (status 201). Format dipaksa PDF di service.

Catatan keamanan: `editedHtml` dikompilasi via openhtml2pdf (server-side, bukan dirender di browser bank), risiko XSS rendah, tapi tetap dokumen internal. Tidak perlu sanitasi tambahan di luar yang ada.

## Frontend — `ulos-ui`

### `src/api/documentApi.ts`
Tambah interface + 2 method (ikuti pola `generateDocument` line 400-431 termasuk cabang `isMockEnabled()`):
- `renderDraft(applicationId, templateCode): Promise<{html, templateName, templateCode}>` → `POST /render-draft`. Mock: ambil `MOCK_TEMPLATES` by code, kembalikan `contentHtml` dgn substitusi `{{...}}` sederhana (atau apa adanya).
- `generateFromHtml(applicationId, templateCode, html): Promise<GeneratedDocument>` → `POST /generate-from-html`. Mock: push `MOCK_DOCUMENTS` baru, `fileFormat: 'PDF'`, `status: 'GENERATED'`.

### Page baru `src/pages/DocumentEditorPage.tsx`
Route detail-style (lazy, suffix `Page`, ikuti pola `TemplateDetailPage`):
- Baca `:id` (applicationId) dari path + `templateCode` dari query (`useSearchParams`).
- `useEffect`: panggil `documentApi.renderDraft(id, templateCode)` → set state `html`.
- Render `<div contentEditable suppressContentEditableWarning>` di-inject `dangerouslySetInnerHTML` awal; ref baca `innerHTML` saat submit. Bungkus dgn frame "kertas" (max-width A4, padding, shadow) supaya mirip preview dokumen.
- Tombol **"Convert to PDF"** (`Button isLoading`): panggil `generateFromHtml(id, templateCode, ref.innerHTML)` → `toast.success` → tutup tab (`window.close()`) atau tampilkan state "Tersimpan, dokumen muncul di tab Generate Document".
- Pakai komponen UI yang ada: `Button`, `toast`, `resolveApiError`, `useLanguage`.

### `src/App.tsx`
Tambah route di grup `application:view` (line 86-90):
`<Route path="/applications/:id/documents/edit" element={<DocumentEditorPage />} />` + lazy import.

### `src/components/document/DocumentGeneratorTab.tsx`
Di `handleGenerate` (line 103-125): cabang berdasarkan `selectedFormat`:
- `'PDF'` → tetap `documentApi.generateDocument(...)` (perilaku sekarang).
- `'DOCX'` (= Word) → **jangan** generate. Buka tab baru:
  `window.open(`/applications/${applicationId}/documents/edit?templateCode=${selectedGenTemplate}`, '_blank')`.
- Opsional: ubah label opsi DOCX (line 234) jadi `'Microsoft Word — Edit lalu PDF'` agar jelas. Refresh listing tidak perlu untuk cabang Word (dokumen muncul setelah convert di tab baru; user refresh manual via tombol yang ada line 307-313).

## Verifikasi end-to-end
1. **Mock mode** (toggle mock aktif): buka aplikasi → tab Generate Document → pilih template, format Word → klik generate → tab baru terbuka, HTML draft tampil & editable → edit teks → Convert to PDF → toast sukses, dokumen PDF GENERATED muncul di listing (refresh).
2. **Backend real**: `cd ulos-document-service && ./mvnw test` (tambah/maintain test untuk `renderDraft` + `generateFromHtml`). Manual: `POST /render-draft` kembalikan HTML hasil Mustache; `POST /generate-from-html` kembalikan entity PDF + file ada di S3 (`/{id}/download` valid PDF).
3. **Regresi**: pilih format PDF langsung → tetap generate tanpa tab baru (perilaku lama utuh).
4. `cd ulos-ui && npm run build` (typecheck lolos).

## File kunci
- `ulos-document-service/.../service/DocumentGeneratorService.java` (refactor + 2 method baru)
- `ulos-document-service/.../adapter/inbound/DocumentGeneratorController.java` (2 endpoint baru)
- `ulos-ui/src/api/documentApi.ts` (2 method + mock)
- `ulos-ui/src/pages/DocumentEditorPage.tsx` (baru)
- `ulos-ui/src/App.tsx` (route baru)
- `ulos-ui/src/components/document/DocumentGeneratorTab.tsx` (cabang Word → window.open)
