# Parameter Management Menu — Frontend-First (Mock-Mode Ready, Backend-Integration Ready)

## Context

**Masalah:** 40+ dropdown/radio/checkbox di seluruh aplikasi loan + portfolio saat ini hardcoded di TypeScript constants (`src/lib/portfolio/constants.ts`, `src/lib/schemas.ts`, wizard components). Setiap kali bank butuh tambah opsi gender baru, segment baru, product type baru, atau nominal tenor baru — wajib ubah kode + redeploy. Backend juga tidak punya facility LOV (`@Enumerated(EnumType.STRING)` saja).

**Tujuan:** Bangun menu **Parameter Management** untuk maintain LOV (List of Values), PRODUCT (parameter dengan metadata), dan CONFIG (key-value settings). Value-nya muncul di aplikasi loan/portfolio sebagai dropdown/checkbox/radio.

**Ruang lingkup phase ini:** **Frontend-only**, mock data ready, siap integrasi backend saat mock dimatikan. Backend service (atau extension ulos-orchestration-service) menyusul di iterasi berikut — kontrak API didefinisikan di plan ini supaya backend tim bisa langsung implement tanpa diskusi ulang.

**Konstrain non-fungsional:**
- ❗ **No perf impact pada consumer screens** — wizard loan punya 10+ dropdown, jangan 10 request paralel saat halaman load.
- Enterprise UI/UX — table-based admin pane, breadcrumb navigation, search/filter, audit-friendly (created/modified metadata).
- Multi-language labels (ID + EN) sejak day 1.
- Stale-while-revalidate caching — first paint dari cache, background refresh.

## Arsitektur

```
┌─────────────────────────────────────────────────────────────┐
│ ADMIN SIDE                                                  │
│ /parameters → ParameterListPage                             │
│   ├─ tabs: LOV | PRODUCT | CONFIG                           │
│   ├─ table: code, name, item count, status, action          │
│   └─ click row → /parameters/:code (detail + items CRUD)    │
└────────────────────────────────┬────────────────────────────┘
                                 │ (admin CRUD)
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│ parameterApi.ts                                             │
│   isMockEnabled() ? MOCK_PARAMETERS : axios →               │
│   GET/POST/PATCH /api/v1/parameters[/{code}[/items[/{id}]]] │
└────────────────────────────────┬────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│ useParameterStore (zustand) — SINGLETON CACHE               │
│   { [code: string]: { items: LovItem[], fetchedAt: Date,    │
│                       status: 'idle'|'loading'|'ready' } }  │
│   loadLov(code) — dedup + stale-while-revalidate            │
└────────────────────────────────┬────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│ CONSUMER SIDE                                               │
│ useLovOptions('LOV_GENDER') → SelectOption[]                │
│ <Select options={options} />  (or Checkbox/Radio group)     │
│                                                             │
│ ► First mount: cache miss → fetch → render                  │
│ ► Subsequent: cache hit → instant render                    │
│ ► After staleMs: serve cached + refresh in background       │
└─────────────────────────────────────────────────────────────┘
```

**Performance kunci:** consumer wizard tidak panggil API 10 kali. Mereka panggil `useLovOptions(code)` → store cek cache, in-flight dedup, atau prefetch batch saat app boot.

## Data Model

```ts
// Parameter (header)
interface Parameter {
  code: string;             // 'LOV_GENDER' (UPPER_SNAKE, immutable)
  name: string;             // 'Gender'
  description?: string;
  category: 'LOV' | 'PRODUCT' | 'CONFIG';
  itemCount: number;        // denormalized for list view
  active: boolean;
  createdAt: string;        // ISO
  createdBy: string;
  modifiedAt: string;
  modifiedBy: string;
}

// LovItem (child) — used for LOV and PRODUCT categories
interface LovItem {
  id: string;               // UUID (mock: 'item-<uuid>')
  parameterCode: string;
  value: string;            // 'MALE' (immutable per item — the code stored in records)
  labelId: string;          // 'Laki-laki'
  labelEn: string;          // 'Male'
  description?: string;
  sortOrder: number;
  active: boolean;
  metadata?: Record<string, unknown>;
                            // PRODUCT category uses this for extras:
                            // { interestRate: 5.5, minAmount: 100000000,
                            //   maxAmount: 5000000000, tenorMonthsMin: 12,
                            //   tenorMonthsMax: 240, secured: true }
}

// Config item (CONFIG category) — single key-value, no list
interface ConfigItem {
  code: string;             // 'CONFIG_MAX_LOAN_AMOUNT'
  value: string;            // '10000000000'
  valueType: 'string' | 'number' | 'boolean' | 'json';
  description?: string;
}
```

**Category rules:**
- **LOV**: simple list — value + labels + sortOrder. Used by 90% of dropdowns. Example: `LOV_GENDER`, `LOV_MARITAL_STATUS`.
- **PRODUCT**: list with rich metadata. Example: `LOV_PRODUCT_TYPE` items carry interest rate, min/max amount, tenor range. Consumer reads `item.metadata.maxAmount` when needed.
- **CONFIG**: single value, not a list. Example: `CONFIG_MAX_LOAN_AMOUNT`. Stored same table, just no items child.

## API Contract (Backend-Ready)

All endpoints return `ApiResponse<T>` wrapper (`ulos-common-core`).

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/api/v1/parameters` | List all parameters (admin overview, paginated) |
| `GET` | `/api/v1/parameters?category=LOV` | Filter by category |
| `GET` | `/api/v1/parameters/{code}` | Single parameter header |
| `GET` | `/api/v1/parameters/{code}/items` | All items for a parameter (consumer-facing — cached) |
| `POST` | `/api/v1/parameters` | Create new parameter (admin) |
| `PATCH` | `/api/v1/parameters/{code}` | Update header (name, description, active) |
| `POST` | `/api/v1/parameters/{code}/items` | Add item |
| `PATCH` | `/api/v1/parameters/{code}/items/{id}` | Update item |
| `DELETE` | `/api/v1/parameters/{code}/items/{id}` | Soft delete (active=false) |

Gateway route nanti: `id=parameter, Path=/api/v1/parameters/**, uri=http://ulos-orchestration:8082` (or new ulos-parameter-service).

Admin endpoints gated `@PreAuthorize("hasAuthority('parameter:manage')")`. Read endpoints (`GET /items`) public to any authenticated user (no per-LOV gating — kalau user bisa lihat loan form, ya butuh dropdown isinya).

## File yang Dibuat / Diubah (Frontend)

### Data + cache layer

**New** `src/types/parameter.ts`:
- `Parameter`, `LovItem`, `ConfigItem`, `ParameterCategory` types per data model di atas.
- Helper type `CreateParameterRequest`, `CreateLovItemRequest`, `UpdateLovItemRequest`.

**New** `src/api/parameterApi.ts`:
- Follow exact pattern dari `src/api/applicationApi.ts:18-95` — `isMockEnabled()` branch.
- 9 fungsi cocok 9 endpoint di atas.
- GET pakai `apiGet` (`src/api/dedup.ts`) — dedup in-flight calls.

**New** `src/store/useParameterStore.ts`:
- Zustand store. State: `{ cache: Map<code, CacheEntry>, loadLov, invalidate }`.
- `CacheEntry = { items: LovItem[], fetchedAt: number, status, error? }`.
- `loadLov(code)`:
  - Cache hit & fresh (< 5 menit): return synchronously.
  - Cache hit & stale: return cached + trigger background refetch (set stale flag).
  - Cache miss: trigger fetch, set loading.
- `invalidate(code)` — dipanggil setelah admin save item; force refetch next access.
- `prefetchHotLovs()` — fire-and-forget batch fetch utk 5-10 LOV paling sering dipakai saat app mount.

**New** `src/hooks/useLovOptions.ts`:
- Signature: `useLovOptions(code: string, opts?: { activeOnly?: boolean })`
- Returns: `{ options: SelectOption[], loading: boolean, error: string | null }`.
- Internally: subscribe to `useParameterStore`, call `loadLov(code)`, transform `items` to `SelectOption[]` (label by current language from `useLanguage()`).
- Auto-filters `active: true` by default.

**New** `src/hooks/useLov.ts`:
- Same as `useLovOptions` but returns raw `LovItem[]` — for consumers that need `metadata` (PRODUCT category).
- Signature: `useLov(code) → { items: LovItem[], loading, error }`.

### Admin UI

**New** `src/pages/ParameterListPage.tsx` (`/parameters` route):
- Page header: title "Parameter Management" + "Create Parameter" button.
- Tabs primitive (`@/components/ui Tabs`): LOV | PRODUCT | CONFIG (count badges per tab).
- Search input (filters code + name).
- Table (`@/components/ui Table`): columns code (mono), name, description, items count, status badge, action.
- Action column: "Manage Items" button → navigate `/parameters/:code` (and "Edit Header" + "Delete" via dropdown menu — defer delete dengan dependency check ke iterasi berikut, sama seperti security menu).
- Pagination via `TablePagination`.
- Loading + empty state via existing primitives.
- Permission gate route-level `parameter:manage`.

**New** `src/pages/ParameterDetailPage.tsx` (`/parameters/:code` route):
- Breadcrumb: Parameter Management → {code}.
- Header card: parameter name, description, category badge, status toggle, "Edit" button → opens header edit modal.
- Section "Items":
  - LOV/PRODUCT category: table of items (columns: value mono, label ID, label EN, sortOrder, status, action). "Add Item" button.
  - CONFIG category: single value editor card (no items table).
- Item table inline action: Edit (modal) + Toggle Active (PATCH active flag).
- Search bar on items.

**New** `src/components/parameter/ParameterCreateModal.tsx`:
- Form: code (auto-uppercase + regex validator `^[A-Z][A-Z0-9_]*$`), name, description, category (radio LOV/PRODUCT/CONFIG).
- Submit → `parameterApi.createParameter` → toast + navigate to detail page.
- Reuse `Modal`, `Input`, `Button` from `@/components/ui`.

**New** `src/components/parameter/ItemCreateEditModal.tsx`:
- Form: value (mono input), labelId, labelEn, sortOrder (number), active (checkbox), description.
- PRODUCT category: extra collapsible "Metadata" section with JSON editor (simple `Textarea` validated as JSON for now — defer rich editor).
- Mode: create (POST) or edit (PATCH).
- Submit → toast + invalidate cache (`useParameterStore.invalidate(code)`) + refresh items.

**New** `src/components/parameter/ConfigValueEditor.tsx`:
- For CONFIG category — single value, valueType selector (string/number/boolean/json), value input adapts.

### Consumer migration (proof — 2 examples)

**Edit** `src/components/wizard/CustomerInfo.tsx` (loan wizard):
- Replace hardcoded `genderOptions = [{value:'MALE',label:'Male'}, ...]` with:
  ```tsx
  const { options: genderOptions } = useLovOptions('LOV_GENDER');
  const { options: maritalOptions } = useLovOptions('LOV_MARITAL_STATUS');
  ```
- Render `<Select options={genderOptions} ... />` — same API, no markup change.

**Edit** `src/lib/portfolio/constants.ts`:
- Mark old arrays `@deprecated` — keep exports as fallback during migration window. Add comment pointing to LOV codes.
- Future PR migrates other consumers; this PR migrates 2 to prove pattern works without perf regression.

### Mock data

**Edit** `src/api/mockData.ts`:
- Append `MOCK_PARAMETERS: Parameter[]` (~40 entries seeded from existing constants).
- Append `MOCK_LOV_ITEMS: Record<code, LovItem[]>` — items for each parameter (e.g. `LOV_GENDER` → MALE/FEMALE/OTHER items with ID+EN labels).
- Append mock CRUD handlers (push to in-memory arrays, return Promise.resolve, same as existing pattern).
- Cover at minimum 8 LOVs end-to-end (consumed in wizard demo): `LOV_GENDER`, `LOV_MARITAL_STATUS`, `LOV_CUSTOMER_TYPE`, `LOV_PRODUCT_TYPE` (PRODUCT category with metadata), `LOV_COLLATERAL_TYPE`, `LOV_INTEREST_TYPE`, `LOV_TENOR_MONTHS`, `LOV_ID_TYPE`. Rest stubbed with name + 0 items (creatable from admin UI).

### Wiring

**Edit** `src/App.tsx`:
- New route inside protected wrapper: `/parameters` → `ParameterListPage`, `/parameters/:code` → `ParameterDetailPage`. Permission `parameter:manage`.

**Edit** `src/config/menuConfig.tsx`:
- New nav item under "admin_section" (same section as Security): `{ path: '/parameters', labelKey: 'parameter_management', icon: <Settings2 />, permission: 'parameter:manage' }`.

**Edit** `src/locales/translations.ts` (ID + EN):
- Keys: `parameter_management`, `parameter_lov`, `parameter_product`, `parameter_config`, `add_parameter`, `parameter_code`, `parameter_name`, `parameter_category`, `parameter_items_count`, `parameter_created`, `parameter_updated`, `add_item`, `edit_item`, `item_value`, `item_label_id`, `item_label_en`, `item_sort_order`, `item_active`, `item_metadata`, `metadata_invalid_json`, `parameter_code_invalid` (regex hint), `manage_items`, `back_to_parameters`.

**Edit** `src/store/useAuthStore.ts` — no change. Permission `parameter:manage` flows through existing JWT `permissions` claim path.

**Edit** `src/main.tsx` or app bootstrap:
- Call `useParameterStore.getState().prefetchHotLovs()` once after auth ready — fire-and-forget. Doesn't block render.

## Reused Existing Helpers

| Existing | Lokasi | Untuk apa |
|----------|--------|-----------|
| `isMockEnabled()` pattern | `src/api/applicationApi.ts:18` | API branching for parameterApi |
| `apiGet` | `src/api/dedup.ts` | In-flight dedup on item fetch |
| Mock array push pattern | `src/api/mockData.ts` | Mock CRUD for parameter items |
| `Modal`, `Tabs`, `Table`, `Input`, `Select`, `Checkbox`, `Textarea`, `Button`, `FormField`, `LoadingSpinner`, `EmptyState`, `SearchToolbar`, `Skeleton` | `@/components/ui` | Admin UI — no new primitives |
| `ProtectedRoute requiredPermission=...` | `src/components/security/ProtectedRoute.tsx` | Route guard for `/parameters` |
| `usePermission`, `<Can>` | `src/hooks/usePermission.ts`, `src/components/security/Can.tsx` | Action gating |
| Zustand store pattern | `src/store/useAuthStore.ts` | Reference for `useParameterStore` |
| `useLanguage()` `t()` + `lang` | `src/contexts/LanguageContext.tsx` | Pick `labelId` vs `labelEn` |
| `toast` + `resolveApiError` | `src/lib/toast.ts`, `src/lib/errorMessages.ts` | Notifications, no `alert()` |
| `useMockConfigStore` | `src/store/useMockConfigStore.ts` | Mock-mode source of truth |
| Existing wizard `<Select>` API | `src/components/ui/Select.tsx` | Consumer migration drops in without markup change |

## Performance Strategy (Non-Negotiable)

1. **Singleton cache** — one fetch per LOV per session (unless invalidated). Multiple components reading `LOV_GENDER` = 1 request.
2. **`apiGet` dedup** — even if cache miss + 5 components mount simultaneously, only 1 in-flight network call.
3. **Stale-while-revalidate** — stale data renders immediately; background refresh updates store; React re-renders consumers automatically via zustand subscription.
4. **Prefetch on boot** — hot LOVs (gender, marital, product type, collateral) loaded post-auth, before wizard navigation. Wizard cache hit on first mount.
5. **Lazy by default** — non-hot LOVs only fetched on consumer mount. Admin pages don't pre-warm consumer cache (different access pattern).
6. **No global refetch on focus** — opt-in if needed later.
7. **`active: true` filter client-side** — server returns all; cache filters; saves round-trip on toggle.
8. **Pagination at admin layer only** — consumer items endpoint returns flat array (small list, < 100 items typical per LOV). PRODUCT can paginate if needed (item count > 200 trigger).
9. **No N+1 on admin list** — `GET /parameters` returns header + `itemCount`, NOT all items.

**Benchmark target**: wizard page first-paint to interactive ≤ 200ms additional vs hardcoded baseline (single round-trip if all hot LOVs prefetched).

## Mock Data Coverage (Examples)

8 fully-seeded parameters proving pattern:

| Code | Category | Items (sample) | Consumer (UI) |
|------|----------|----------------|---------------|
| `LOV_GENDER` | LOV | MALE/Laki-laki/Male, FEMALE/Perempuan/Female | `CustomerInfo` wizard |
| `LOV_MARITAL_STATUS` | LOV | SINGLE, MARRIED, DIVORCED, WIDOWED | `CustomerInfo` wizard |
| `LOV_CUSTOMER_TYPE` | LOV | INDIVIDUAL, NON_INDIVIDUAL | `NewPortfolioPage` |
| `LOV_PRODUCT_TYPE` | PRODUCT | KPR (metadata: tenorMax=240, secured=true), PL (tenorMax=60, secured=false), KMK, KI, CC, PRK | `FacilityStep` wizard |
| `LOV_COLLATERAL_TYPE` | LOV | HOUSE, APARTMENT, LAND, VEHICLE | `CollateralStep` wizard |
| `LOV_INTEREST_TYPE` | LOV | FIXED, FLOATING, HYBRID | `FacilityStep` |
| `LOV_TENOR_MONTHS` | LOV | 12, 24, 36, 48, 60, 120, 180, 240 | `FacilityStep` |
| `LOV_ID_TYPE` | LOV | KTP, PASSPORT, KITAS, NPWP | `CustomerInfo` wizard |

Remaining 30+ LOV from inventory (gender, religion, education, business type, etc.) seeded sebagai parameter header only with empty items[] — admin bisa tambah items dari UI sebagai demo.

## UI/UX Standards (Enterprise)

- **Layout**: side-padded container `max-w-7xl`, consistent dengan SecurityModulePage.
- **Tabs**: pill style sama dengan SecurityModulePage tabs.
- **Table**: zebra-light, sticky header, hover row highlight, mono font untuk code/value columns.
- **Action column**: ghost icon buttons (Edit, Toggle, Manage) — no inline forms.
- **Modal forms**: 2-column grid on `md:`, label-top inputs, primary CTA right.
- **Empty state**: `<EmptyState>` primitive with action button "Create First Parameter".
- **Search**: debounced 250ms (existing `SearchToolbar` pattern).
- **Validation feedback**: inline error under field (existing `FormField` pattern).
- **Confirm dialogs**: dipakai hanya saat destructive (delete/deactivate) — `Dialog` primitive.
- **Audit metadata visible**: created/modified timestamps + actor di detail page footer.
- **Code immutability**: code (LOV_*) tidak editable setelah create — readonly with copy button.
- **Language toggle**: same labels in ID/EN editable side-by-side in item modal.

## Eksekusi Order

1. **Types + API + mock** — `parameter.ts` types → `parameterApi.ts` (mock branch first) → `mockData.ts` seed 8 LOV. Verify in browser console.
2. **Store + hooks** — `useParameterStore` → `useLov` / `useLovOptions`. Test via DevTools store inspector.
3. **Admin pages** — `ParameterListPage` → `ParameterDetailPage` → modals. Wire route + menu config. tsc clean.
4. **Consumer migration (2 fields proof)** — `CustomerInfo` → `LOV_GENDER` + `LOV_MARITAL_STATUS`. Measure render perf in DevTools (no waterfall, no extra requests beyond initial).
5. **Translations** — add 20 keys × 2 langs.
6. **Bootstrap prefetch** — wire `prefetchHotLovs()` in `App.tsx` after auth.
7. **Manual QA** — toggle mock off (when backend ready) → verify UI works against real endpoint without code change.

## Verification

**Frontend dev** (`cd ulos-ui && npm run dev`):
1. Login `admin01` → menu "Parameter Management" muncul.
2. List page: 8 seeded LOV tampil dengan item count, tab filter works.
3. Click `LOV_GENDER` → detail page shows MALE/FEMALE items.
4. Click "Add Item" → modal → fill value `OTHER`, labels → submit → toast + table refresh + cache invalidated.
5. Buka loan wizard → CustomerInfo step → gender dropdown sekarang berisi MALE/FEMALE/OTHER (cache cek di Network tab: 1 request initial, 0 request saat dropdown re-render).
6. Toggle bahasa ID/EN — labels switch tanpa refetch.
7. Negative: non-admin user → menu tidak muncul, direct nav `/parameters` → `/unauthorized`.
8. Create new parameter `LOV_RELIGION` → category LOV → add 6 items → consume di wizard step baru (smoke).

**Performance check** (Chrome DevTools Network tab):
- Boot → 1 batch request `prefetchHotLovs()` (≤ 8 requests parallel).
- Open wizard CustomerInfo → 0 new requests untuk dropdown (cache hit).
- Open wizard ApplicationInfo (non-hot LOV) → 1 request per missing LOV, max.

**Mock-off verification** (siap saat backend ready):
- Set `VITE_USE_MOCK=false` di `.env.local` + restart dev server.
- Same UI works against backend endpoint (assuming backend implements contract).
- No code change required — only env toggle.

## Out of Scope (Iterasi Berikut)

- Backend service implementation (`ulos-orchestration-service` extension atau `ulos-parameter-service` baru). Plan ini define kontrak; backend tim follow.
- Migrate sisa ~38 hardcoded LOV ke parameter. PR ini migrate 2 sebagai proof + pattern docs.
- Bulk import/export CSV.
- Versioning + draft/publish workflow (LOV history).
- Per-LOV permission (e.g. `parameter:lov:product:edit`).
- Approval workflow (maker-checker) untuk parameter changes — defer sesuai security menu.
- Rich JSON metadata editor untuk PRODUCT — pakai textarea dulu, upgrade ke schema-driven form (JSON Schema) saat butuh.
- LOV usage tracking (which fields consume this LOV — for impact analysis before delete).
- Test suite (Vitest) — manual QA dulu, automation ditambah saat consumer migration full scope.

## Risk & Mitigation

| Risk | Mitigation |
|------|------------|
| Cache stale → admin update tidak langsung muncul di consumer | `invalidate(code)` setelah save admin. Optional: WebSocket push (defer). |
| LOV code typo di consumer → silent empty dropdown | Add TypeScript union type `LovCode` generated dari mock array — compile-time check. Console.warn jika fetch returns empty + log code. |
| `metadata` JSON field bug pada PRODUCT | Strict JSON validation di item modal; runtime guard `typeof metadata?.maxAmount === 'number'`. |
| Prefetch race during slow network | Fire-and-forget, consumer fallback to in-line fetch via `loadLov`. Loading spinner shown via `Skeleton` per dropdown. |
| Auth boundary — anonymous fetch of parameters | All endpoints require JWT (gateway filter chain handles). No anonymous access. |
| Large LOV (e.g. branch codes 1000+) → big payload | Defer pagination to backend phase. UI ready: items endpoint can return paginated; cache stores aggregated. For now mock LOV ≤ 20 items. |
| Multiple language fields out of sync | Single modal edits both labelId + labelEn together; required validation. |
| Consumer migration regression — wizard broken | Migrate 1 field at a time per PR; visual regression manual QA; old constant kept until consumer cut over. |
| Backend not yet built when UI ships | Mock-mode default ON for prod-like demo; toggle off only when backend deployed. Feature-flag the menu via `parameter:manage` permission — admin doesn't see menu until granted. |
