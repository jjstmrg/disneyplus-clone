# PR — Revisi Multi-Replica Readiness Docs (Post-Verification)

## Context

Review awal (8 file `docs/pr-multi-replica/*.md`) berisi beberapa **claim shaky berbasis grep saja**. Setelah baca file actual (FlowableAsyncConfig, ReconciliationRecordRepository, GatewaySecurityConfig + RateLimiterConfig, DmnDeploymentService, PermissionMappingService, KeycloakAdminConfig, docker-compose.yml Kafka), beberapa verdict WAJIB dikoreksi. Plan ini ringkas perubahan yang harus diapply ke 8 doc.

---

## Koreksi per service

### `api-gateway.md` — MAJOR REVISION (PASS unconditional)

**Sebelumnya saya bilang**: "verify ada rate limiter? Kalau in-memory pecah. Recommend Redis-backed."

**Faktanya** (after read `RateLimiterConfig.java`):
- ✅ Sudah pakai `RedisRateLimiter` (Spring Cloud Gateway built-in).
- ✅ `KeyResolver` resolve by IP.
- ✅ `LocalRateLimitFilter` apply ke `/api/auth/**` (1 req/s, burst 20).
- ✅ Redis state shared antar pod by design.

**Action**: hapus section "[VERIFY] V1 Rate limiter" + section "Changes #1 Redis-backed rate limiter" — gantikan dengan **PASS confirmed** + evidence `RateLimiterConfig.java:33-39`. Tetap ada catatan: tambah `userKeyResolver` based on JWT sub (bukan IP) supaya rate limit per-user, bukan per-NAT-exit-IP.

---

### `rule-service.md` — MAJOR REVISION (PASS confirmed, beda alasan)

**Sebelumnya saya bilang**: "verify DMN runtime upload path. Kalau ada → wajib persist ke shared storage."

**Faktanya** (after read `DmnDeploymentService.java`):
- ✅ Runtime DMN upload exists via `POST /dmn/deploy` controller.
- ✅ Persistence path: `dmnRepositoryService.createDeployment().addString(...).deploy()` (Flowable engine line 49-52) → Flowable simpan ke DB tables `ACT_RE_DEPLOYMENT_`/`ACT_RE_DECISION_`.
- ✅ PLUS audit copy ke project DB `DmnDeploymentEntity` line 75.
- ✅ Semua pod baca dari DB yang sama → multi-replica safe by design.

**Action**: ganti "[VERIFY] V1 DMN runtime upload" jadi **[PASS] P5** dengan evidence `DmnDeploymentService.java:49-75`. Hapus "Changes #1 Verify DMN runtime upload" (tidak perlu).

---

### `integration-service.md` — DOWNGRADE (PASS jadi NEEDS-FIX, NEW BLOCKER)

**Sebelumnya saya bilang**: "Reconciliation `FOR UPDATE SKIP LOCKED` ✅ PASS."

**Faktanya** (after read `ReconciliationRecordRepository.java`):
- ✅ `@Lock(LockModeType.PESSIMISTIC_WRITE)` + `lock.timeout=-2` (Hibernate maps to SKIP LOCKED on Postgres) — multi-pod no-block confirmed.
- ❌ **TAPI**: query line 28 `"SELECT r FROM ReconciliationRecordEntity r WHERE r.reconciled = false AND r.vendorCode = :vendorCode"` — **TIDAK ADA LIMIT / Pageable / setMaxResults**.
- **Impact**: pod A `findUnreconciledWithLock("CORE_BANKING")` di T=0s lock SEMUA unreconciled rows (mis. 5000 rows). Pod B + C jalan T=0.1s, skip-locked → return empty list. Throughput = single pod. Multi-replica = no scale-out benefit.
- Plus risiko: kalau 5000 rows process sequentially di pod A (line 53-61 for-loop), `@Transactional` hold lock 5000×latency. Pod B+C idle.

**Action**: add **[BLOCKER] B3** untuk integration-service:
- Modify query: tambah `LIMIT 100` di JPQL (atau pakai Spring Data `Pageable`).
- Modify `CoreBankingReconciliationJob.reconcileTransactions()`: ambil batch size kecil (50-100), commit per batch supaya release lock cepat.

---

### `bpm-service.md` — REFINE (FlowableAsyncConfig confirmed default-reliant)

**Sebelumnya saya bilang**: "Asumsi tanpa cek: Flowable default cluster-safe via `ACT_RU_JOB` lock."

**Faktanya** (after read `FlowableAsyncConfig.java`):
- File ini HANYA setup `flowableTaskExecutor` (Spring @Async) + virtual thread executor untuk Flowable AsyncExecutor.
- **TIDAK** explicit set `asyncExecutorActivate`, `asyncExecutorAsyncJobLockTimeInMillis`, lock owner. Relies on Flowable defaults (yang memang cluster-safe).
- **Virtual thread + JDBC pinning risk**: AsyncExecutor jalan di virtual threads. Driver Postgres JDBC <42.7.x bisa pin saat `synchronized`. Project pakai... need check pom.

**Action**: ganti "[BLOCKER] B2 Flowable async executor cluster config" jadi **[NEEDS-FIX] N3**:
- Tambah explicit cluster config di `FlowableAsyncConfig.java` (lockTime ≥5min, default async-job lock owner = hostname via Flowable built-in).
- Verify Postgres JDBC driver ≥ 42.7.2 (virtual thread support tanpa pinning).
- Add load test: 100 concurrent process-start, confirm no double-delegate-execute.

---

### `iam-service.md` — REFINE (verified mostly PASS)

**Sebelumnya saya bilang**: "Verify Keycloak Admin pool, verify audit log async/sync."

**Faktanya**:
- `KeycloakAdminConfig.java`: 1 `Keycloak` bean shared, no connection pool override. Keycloak admin client maintains internal RestEasy HTTP connection pool (default size 10). OK untuk 3 pod × low admin call frequency.
- `PermissionMappingService.java`: pure pass-through ke `permissionRepository.findPermissionsByRoleCodes(roles)` — NO cache, NO state. Multi-replica safe but every call hits DB.
- `KeycloakAdminServiceImpl.java:414` audit log = sync DB write via `auditRepo.save(entry)`. Multi-replica safe (each pod write own audit row, no contention).

**Action**: ganti "[VERIFY] V1 Keycloak Admin pool" + "V2 audit log" jadi **[PASS]** with evidence. Tetap rekomendasikan Redis cache untuk `PermissionMappingService` (low priority, optimisasi).

---

### `orchestration-service.md` — VALIDATED (no major revision)

Findings di doc original sudah benar (4 file core dibaca penuh saat audit awal). No revision needed kecuali:
- Cross-check Kafka partition default: confirmed `docker-compose.yml` Kafka **TIDAK** set `KAFKA_NUM_PARTITIONS` → defaults to `1`. My claim correct. Tambah evidence link ke docker-compose.

---

### `notification-service.md` — VALIDATED (no major revision)

- `DashboardSseService.java:19` — `CopyOnWriteArrayList<SseEmitter>` local-only, confirmed ✅ correct.
- Unique-groupId-per-pod recommendation tetap valid.

---

### `README.md` — UPDATE matrix

Revisi tabel verdict:

| Service | Sebelum | Sesudah |
|---|---|---|
| `api-gateway` | ✅ PASS (with optional Redis suggestion) | ✅ PASS unconditional (Redis rate limiter ALREADY in place) |
| `rule-service` | ✅ PASS (with caveats: verify DMN) | ✅ PASS confirmed (DMN persisted via Flowable engine to shared DB) |
| `integration-service` | ⚠️ NEEDS-FIX (mock + Hikari) | ❌ NEEDS-FIX (BLOCKER: reconciliation batch unbounded → single-pod throughput) |
| `bpm-service` | ❌ NOT READY (3 blocker) | ❌ NOT READY (2 blocker + 1 needs-fix Flowable virtual thread driver compat) |
| `iam-service` | ✅ PASS | ✅ PASS confirmed + evidence |
| `orchestration-service` | ❌ NOT READY | ❌ NOT READY (no change) |
| `notification-service` | ❌ NOT READY | ❌ NOT READY (no change) |

---

## Confidence Update

| Service | Sebelum | Sesudah |
|---|---|---|
| orchestration | 85% | **95%** (cross-check Kafka broker config confirmed) |
| bpm | 60% | **80%** (FlowableAsyncConfig read, but no integration test yet) |
| notification | 80% | **85%** (no new info but no contradict) |
| integration | 65% | **95%** (repo SQL read, new finding discovered) |
| api-gateway | 40% | **90%** (RateLimiterConfig + SecurityConfig read) |
| rule | 40% | **85%** (DmnDeploymentService read) |
| iam | 40% | **85%** (KeycloakAdminConfig + PermissionMappingService read) |

---

## Files Yang Akan Dimodifikasi (post-approval)

| File | Action |
|---|---|
| `docs/pr-multi-replica/README.md` | Update matrix verdict + add evidence row |
| `docs/pr-multi-replica/api-gateway.md` | Remove "verify rate limiter" section, mark PASS with evidence |
| `docs/pr-multi-replica/rule-service.md` | Remove "verify DMN" section, mark PASS with evidence |
| `docs/pr-multi-replica/integration-service.md` | Add new BLOCKER B3 (reconciliation no LIMIT), include patch query |
| `docs/pr-multi-replica/bpm-service.md` | Refine FlowableAsyncConfig finding, add Postgres JDBC driver version check |
| `docs/pr-multi-replica/iam-service.md` | Convert "VERIFY" items to PASS with evidence |
| `docs/pr-multi-replica/orchestration-service.md` | Minor: cite docker-compose Kafka evidence |
| `docs/pr-multi-replica/notification-service.md` | No change |

---

## Verification

Setelah apply revisi, user bisa:
1. `git diff docs/pr-multi-replica/` — lihat semua perubahan.
2. Check matrix di `README.md` konsisten dengan per-file detail.
3. Spot-check 1-2 evidence (mis. `RateLimiterConfig.java:33-39` referenced di api-gateway.md, baca file → match).

---

## Catatan Honest

Confidence sekarang lebih tinggi tapi **TIDAK 100%**. Gap yang masih ada:

1. **Postgres JDBC driver version** — belum cek `pom.xml` parent / Spring Boot 3.4 default version untuk virtual thread compat.
2. **Cloud SQL tier produksi** — Hikari math masih asumsi (`db-custom-2-7680` ≈ 100 conn). Wajib konfirmasi tier sebenarnya.
3. **Spring Modulith ApplicationEventPublisher** — orchestration `OutboxEventDispatcher` line 39 publish local Spring event. Belum trace subscriber. Kalau ada subscriber yang depend on pod itu → state leak antar replica.
4. **Helm/kustomize overlay** — confirmed cuma `infra/k8s/base/kustomization.yaml` exists, no `overlays/`. K8s manifest bpm/notification/iam beneran missing — wajib dibuat per PR.
5. **Production Kafka broker** — `docker-compose.yml` default = 1 partition. Produksi (Confluent Cloud / MSK) bisa beda. Wajib konfirmasi.

Mau saya apply revisi ke 8 doc setelah approval?
